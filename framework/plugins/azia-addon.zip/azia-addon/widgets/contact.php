<?php

/**
 * Contact Section Widget
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Contact Section Widget
 *
 * Custom Elementor widget for a contact section with form and interactive elements
 */
class Elementor_Contact_Widget extends \Elementor\Widget_Base
{

    /**
     * Get widget name.
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'contact_section';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Contact Section', 'azia-addon');
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-form-horizontal';
    }

    /**
     * Get widget categories.
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['azia'];
    }

    /**
     * Get widget keywords.
     *
     * @return array Widget keywords.
     */
    public function get_keywords()
    {
        return ['contact', 'form', 'get in touch', 'connect'];
    }

    /**
     * Register widget controls.
     */
    protected function register_controls()
    {
        // Section Header Controls
        $this->start_controls_section(
            'section_header',
            [
                'label' => __('Section Header', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'badge_text',
            [
                'label' => __('Badge Text', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Get In Touch', 'azia-addon'),
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => __('Title', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Let\'s Create <span class="gradient-text relative inline-block transform transition-all">Something Amazing</span>', 'azia-addon'),
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => __('Description', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Ready to transform your social media presence? Let\'s discuss how we can help you build your brand, connect with your audience, and drive real results.', 'azia-addon'),
            ]
        );

        $this->end_controls_section();

        // Contact Form Controls
        $this->start_controls_section(
            'contact_form_section',
            [
                'label' => __('Contact Form', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'form_shortcode',
            [
                'label' => __('Contact Form 7 Shortcode', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'description' => __('Enter your Contact Form 7 shortcode here. Example: [contact-form-7 id="123" title="Contact form 1"]', 'azia-addon'),
                'default' => '',
                'placeholder' => __('[contact-form-7 id="123" title="Contact form 1"]', 'azia-addon'),
            ]
        );
 

        $this->end_controls_section();

        // Availability Card
        $this->start_controls_section(
            'availability_section',
            [
                'label' => __('Availability Card', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'availability_icon',
            [
                'label' => __('Icon', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-calendar-check',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $this->add_control(
            'availability_title',
            [
                'label' => __('Title', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Current Availability', 'azia-addon'),
            ]
        );

        $this->add_control(
            'availability_subtitle',
            [
                'label' => __('Subtitle', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Taking new clients for June 2025', 'azia-addon'),
            ]
        );

        $this->add_control(
            'content_creation_label',
            [
                'label' => __('Content Creation Label', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Content Creation', 'azia-addon'),
            ]
        );

        $this->add_control(
            'content_creation_status',
            [
                'label' => __('Content Creation Status', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Limited Spots', 'azia-addon'),
            ]
        );

        $this->add_control(
            'content_creation_percentage',
            [
                'label' => __('Content Creation Availability', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 85,
                ],
            ]
        );

        $this->add_control(
            'strategy_sessions_label',
            [
                'label' => __('Strategy Sessions Label', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Strategy Sessions', 'azia-addon'),
            ]
        );

        $this->add_control(
            'strategy_sessions_status',
            [
                'label' => __('Strategy Sessions Status', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Available', 'azia-addon'),
            ]
        );

        $this->add_control(
            'strategy_sessions_percentage',
            [
                'label' => __('Strategy Sessions Availability', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 40,
                ],
            ]
        );

        $this->add_control(
            'discovery_call_text',
            [
                'label' => __('Discovery Call Text', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Book a Discovery Call', 'azia-addon'),
            ]
        );

        $this->add_control(
            'discovery_call_url',
            [
                'label' => __('Discovery Call URL', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'azia-addon'),
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $this->end_controls_section();

        // Contact Information
        $this->start_controls_section(
            'contact_info_section',
            [
                'label' => __('Contact Information', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'email_icon',
            [
                'label' => __('Email Icon', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-envelope',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $this->add_control(
            'email_address',
            [
                'label' => __('Email Address', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('hello@aziasocial.com', 'azia-addon'),
            ]
        );

        $this->add_control(
            'phone_icon',
            [
                'label' => __('Phone Icon', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-phone-alt',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $this->add_control(
            'phone_number',
            [
                'label' => __('Phone Number', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('(555) 123-4567', 'azia-addon'),
            ]
        );

        $this->end_controls_section();

        // Social Media
        $this->start_controls_section(
            'social_media_section',
            [
                'label' => __('Social Media', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'social_heading',
            [
                'label' => __('Social Heading', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Connect With Me', 'azia-addon'),
            ]
        );

        $social_repeater = new \Elementor\Repeater();

        $social_repeater->add_control(
            'social_icon',
            [
                'label' => __('Icon', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fab fa-instagram',
                    'library' => 'fa-brands',
                ],
            ]
        );

        $social_repeater->add_control(
            'social_link',
            [
                'label' => __('Link', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'azia-addon'),
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $social_repeater->add_control(
            'social_color',
            [
                'label' => __('Background Color', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'linear-gradient(90deg, #833AB4, #FD1D1D, #FCB045)',
            ]
        );

        $this->add_control(
            'social_icons',
            [
                'label' => __('Social Icons', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $social_repeater->get_controls(),
                'default' => [
                    [
                        'social_icon' => [
                            'value' => 'fab fa-instagram',
                            'library' => 'fa-brands',
                        ],
                        'social_link' => [
                            'url' => '#',
                        ],
                        'social_color' => 'linear-gradient(90deg, #833AB4, #FD1D1D, #FCB045)',
                    ],
                    [
                        'social_icon' => [
                            'value' => 'fab fa-tiktok',
                            'library' => 'fa-brands',
                        ],
                        'social_link' => [
                            'url' => '#',
                        ],
                        'social_color' => '#000000',
                    ],
                    [
                        'social_icon' => [
                            'value' => 'fab fa-youtube',
                            'library' => 'fa-brands',
                        ],
                        'social_link' => [
                            'url' => '#',
                        ],
                        'social_color' => '#FF0000',
                    ],
                    [
                        'social_icon' => [
                            'value' => 'fab fa-linkedin-in',
                            'library' => 'fa-brands',
                        ],
                        'social_link' => [
                            'url' => '#',
                        ],
                        'social_color' => '#0077B5',
                    ],
                    [
                        'social_icon' => [
                            'value' => 'fab fa-twitter',
                            'library' => 'fa-brands',
                        ],
                        'social_link' => [
                            'url' => '#',
                        ],
                        'social_color' => '#1DA1F2',
                    ],
                ],
                'title_field' => '{{{ social_icon.value }}}',
            ]
        );

        $this->end_controls_section();


        // Style Tabs
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Colors', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
       // Primary Color
       $this->add_control(
        'primary_color',
        [
            'label' => esc_html__('Primary Color', 'azia-addon'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#0ea5e9',
            'selectors' => [],
            'global' => [
                'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_PRIMARY
            ]
        ]
    );

    // Secondary Color
    $this->add_control(
        'secondary_color',
        [
            'label' => esc_html__('Secondary Color', 'azia-addon'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#6366f1',
            'selectors' => [],
            'global' => [
                'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_SECONDARY
            ]
        ]
    );

    // Accent_color Color
    $this->add_control(
        'accent_color_color',
        [
            'label' => esc_html__('Accent_color Color', 'azia-addon'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#f6339a',
            'selectors' => [],
            'global' => [
                'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_ACCENT
            ]
        ]
    );
        $this->end_controls_section();

    
    }

    /**
     * Render widget output on the frontend.
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        // Colors
        $primary_color = !empty($settings['primary_color']) ? $settings['primary_color'] : '#0ea5e9'; //sky
        $secondary_color = !empty($settings['secondary_color']) ? $settings['secondary_color'] : '#6366f1'; //indigo
        $accent_color = !empty($settings['accent_color_color']) ? $settings['accent_color_color'] : '#f6339a'; //pink


        // Get URLs with proper formats
        $discovery_call_url = !empty($settings['discovery_call_url']['url']) ? $settings['discovery_call_url']['url'] : '#';
        $discovery_call_target = !empty($settings['discovery_call_url']['is_external']) ? ' target="_blank"' : '';

        // Get slider values
        $content_creation_percentage = isset($settings['content_creation_percentage']['size']) ? $settings['content_creation_percentage']['size'] : 85;
        $strategy_sessions_percentage = isset($settings['strategy_sessions_percentage']['size']) ? $settings['strategy_sessions_percentage']['size'] : 40;

?>

        <!-- Contact Section -->
        <section class="py-24 bg-gray-50 relative overflow-hidden" id="contact" style="--primary-color: <?php echo esc_attr($primary_color); ?>; --secondary-color: <?php echo esc_attr($secondary_color); ?>; --accent-color: <?php echo esc_attr($accent_color); ?>;">
            <!-- Advanced background elements -->
            <div class="absolute inset-0 -z-10 overflow-hidden">
                <!-- Layered gradient meshes -->
                <div class="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-white via-gray-50 to-white opacity-70"></div>
                <div class="absolute -top-96 -left-96 w-[800px] h-[800px] rounded-full blur-3xl opacity-60" style="background: linear-gradient(to bottom right, <?php echo esc_attr(adjust_color_brightness($accent_color, 50, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>);"></div>
                <div class="absolute -bottom-64 -right-64 w-[600px] h-[600px] rounded-full blur-3xl opacity-50" style="background: linear-gradient(to top right, <?php echo esc_attr(adjust_color_brightness($primary_color, 50, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>);"></div>
            </div>

            <!-- Interactive floating elements -->
            <div class="absolute bottom-1/4 right-20 w-8 h-8 rounded-lg opacity-20 floating" style="background-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 200, 1)); ?>; transform-origin: center; animation: floatAndRotate 8s ease-in-out infinite;"></div>
            <div class="absolute top-1/3 left-16 w-6 h-6 border-2 rounded-full opacity-30 floating floating-delay-2" style="border-color: <?php echo esc_attr(adjust_color_brightness($accent_color, 300, 1)); ?>; transform-origin: center; animation: floatAndRotate 7s ease-in-out infinite reverse;"></div>

            <div class="container mx-auto px-6 relative z-10">
                <!-- Section Header -->
                <div class="text-center mb-16 max-w-3xl mx-auto perspective-element">
                    <!-- Badge -->
                    <div class="inline-block px-4 py-1.5 backdrop-blur-md rounded-full text-sm font-semibold mb-5 shadow-sm badge-animation relative" style="background: linear-gradient(to right, <?php echo esc_attr(adjust_color_brightness($primary_color, 100, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 100, 1)); ?>); color: <?php echo esc_attr($secondary_color); ?>;">
                        <div class="absolute inset-0 rounded-full opacity-0 badge-pulse" style="background: linear-gradient(to right, <?php echo esc_attr(adjust_color_brightness($primary_color, 200, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 200, 1)); ?>);"></div>
                        <span class="flex items-center relative z-10">
                            <span class="w-2 h-2 rounded-full mr-2 pulse-ring" style="background-color: <?php echo esc_attr($secondary_color); ?>;"></span>
                            <span><?php echo esc_html($settings['badge_text']); ?></span>
                        </span>
                    </div>

                    <h2 class="text-4xl md:text-5xl font-bold mb-6 tracking-tight perspective-title fade-in-effect">
                        <?php echo wp_kses_post($settings['title']); ?>
                    </h2>

                    <p class="text-lg text-gray-600 max-w-2xl mx-auto perspective-content fade-in-effect effect-1">
                        <?php echo wp_kses_post($settings['description']); ?>
                    </p>
                </div>

                <!-- Contact Content -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ">
                    <!-- Left Side - Contact Form -->
                    <?php if (!empty($settings['form_shortcode'])) : ?>
                        <div class="modern-card rounded-3xl overflow-hidden p-8 hover-up fade-in-effect effect-1">
                            <div class="cf7-styled-form">
                                <?php echo do_shortcode($settings['form_shortcode']); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    <!-- Right Side - Contact Info -->
                    <div class="flex flex-col space-y-8 fade-in-effect effect-2">
                        <!-- Availability Card -->
                        <div class="modern-card p-8 rounded-3xl hover-up relative overflow-hidden ">
                            <!-- Decorative accent -->
                            <div class="absolute -top-10 -right-10 w-24 h-24 rounded-full" style="background-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>;"></div>

                            <div class="relative z-10">
                                <div class="flex items-center mb-6">
                                    <span class="inline-flex items-center justify-center w-12 h-12 rounded-xl text-green-500 mr-4" style="background-color: #DCFCE7;">
                                        <i class="<?php echo esc_attr($settings['availability_icon']['value']); ?> text-xl"></i>
                                    </span>
                                    <div>
                                        <h3 class="text-xl font-bold text-gray-800"><?php echo esc_html($settings['availability_title']); ?></h3>
                                        <p class="text-gray-600"><?php echo esc_html($settings['availability_subtitle']); ?></p>
                                    </div>
                                </div>

                                <div class="space-y-3">
                                    <div class="flex justify-between items-center">
                                        <span class="text-gray-600"><?php echo esc_html($settings['content_creation_label']); ?></span>
                                        <span class="text-gray-800 font-medium"><?php echo esc_html($settings['content_creation_status']); ?></span>
                                    </div>
                                    <div class="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                                        <div class="h-full rounded-full" style="width: <?php echo esc_attr($content_creation_percentage); ?>%; background: linear-gradient(to right, <?php echo esc_attr($primary_color); ?>, <?php echo esc_attr($secondary_color); ?>);"></div>
                                    </div>

                                    <div class="flex justify-between items-center mt-2">
                                        <span class="text-gray-600"><?php echo esc_html($settings['strategy_sessions_label']); ?></span>
                                        <span class="text-gray-800 font-medium"><?php echo esc_html($settings['strategy_sessions_status']); ?></span>
                                    </div>
                                    <div class="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                                        <div class="h-full rounded-full" style="width: <?php echo esc_attr($strategy_sessions_percentage); ?>%; background: linear-gradient(to right, <?php echo esc_attr($secondary_color); ?>, <?php echo esc_attr($accent_color); ?>);"></div>
                                    </div>
                                </div>

                                <a href="<?php echo esc_url($discovery_call_url); ?>" <?php echo $discovery_call_target; ?> class="inline-block mt-6 font-medium transition-colors group" style="color: <?php echo esc_attr($secondary_color); ?>; hover:color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 600, 1)); ?>;">
                                    <?php echo esc_html($settings['discovery_call_text']); ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 inline-block ml-1 transition-transform duration-300 group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                    </svg>
                                </a>
                            </div>
                        </div>

                        <!-- Contact Information Cards -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Email -->
                            <div class="modern-card p-6 rounded-3xl hover-up relative overflow-hidden">
                                <div class="flex items-start">
                                    <span class="inline-flex items-center justify-center w-10 h-10 rounded-xl mr-4 flex-shrink-0" style="background-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 100, 1)); ?>; color: <?php echo esc_attr($secondary_color); ?>;">
                                        <i class="<?php echo esc_attr($settings['email_icon']['value']); ?>"></i>
                                    </span>
                                    <div>
                                        <h3 class="text-sm font-semibold text-gray-500 mb-1"><?php echo esc_html__("Email"); ?></h3>
                                        <p class="text-gray-800 font-medium"><?php echo esc_html($settings['email_address']); ?></p>
                                    </div>
                                </div>
                            </div>

                            <!-- Phone -->
                            <div class="modern-card p-6 rounded-3xl hover-up relative overflow-hidden">
                                <div class="flex items-start">
                                    <span class="inline-flex items-center justify-center w-10 h-10 rounded-xl mr-4 flex-shrink-0" style="background-color: <?php echo esc_attr(adjust_color_brightness($accent_color, 100, 1)); ?>; color: <?php echo esc_attr($accent_color); ?>;">
                                        <i class="<?php echo esc_attr($settings['phone_icon']['value']); ?>"></i>
                                    </span>
                                    <div>
                                        <h3 class="text-sm font-semibold text-gray-500 mb-1"><?php echo esc_html__("Phone"); ?></h3>
                                        <p class="text-gray-800 font-medium"><?php echo esc_html($settings['phone_number']); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Social Media Icons -->
                        <div class="modern-card p-8 rounded-3xl hover-up">
                            <h3 class="text-xl font-bold text-gray-800 mb-5"><?php echo esc_html($settings['social_heading']); ?></h3>

                            <div class="flex flex-wrap gap-4">
                                <?php foreach ($settings['social_icons'] as $social) :
                                    $social_url = !empty($social['social_link']['url']) ? $social['social_link']['url'] : '#';
                                    $social_target = !empty($social['social_link']['is_external']) ? ' target="_blank"' : '';
                                    $social_bg = $social['social_color'];
                                ?>
                                    <a href="<?php echo esc_url($social_url); ?>" <?php echo $social_target; ?> class="w-12 h-12 rounded-xl flex items-center justify-center text-white transition-transform hover:scale-110 neon-glow" style="background: <?php echo esc_attr($social_bg); ?>">
                                        <i class="<?php echo esc_attr($social['social_icon']['value']); ?> text-xl"></i>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Add JavaScript for interactive elements -->
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Initialize hover effects
                const hoverElements = document.querySelectorAll('.hover-up');

                if (hoverElements.length > 0) {
                    hoverElements.forEach(element => {
                        element.addEventListener('mouseenter', function() {
                            this.style.transform = 'translateY(-5px)';
                            this.style.boxShadow = '0 15px 30px rgba(0, 0, 0, 0.1)';
                        });

                        element.addEventListener('mouseleave', function() {
                            this.style.transform = 'translateY(0)';
                            this.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.05)';
                        });
                    });
                }
            });
        </script>
<?php
    }
}
