<?php

/**
 * Social Media Services Widget
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Social Media Services Widget
 *
 * Custom Elementor widget for a social media services section
 */
class Elementor_Service_Widget extends \Elementor\Widget_Base
{

    /**
     * Get widget name.
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'social_media_services';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Social Media Services', 'azia-addon');
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-apps';
    }

    /**
     * Get widget categories.
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['azia'];
    }

    /**
     * Get widget keywords.
     *
     * @return array Widget keywords.
     */
    public function get_keywords()
    {
        return ['services', 'social media', 'content', 'strategy'];
    }

    /**
     * Register widget controls.
     */
    protected function register_controls()
    {
        // Section Header Controls
        $this->start_controls_section(
            'section_header',
            [
                'label' => __('Section Header', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'badge_text',
            [
                'label' => __('Badge Text', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Premium Services', 'azia-addon'),
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => __('Title', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Elevate Your <span class="gradient-text relative inline-block transform transition-all">Social Presence</span>', 'azia-addon'),
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => __('Description', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Craft an impactful brand story across platforms with data-driven strategies and creative content that connects, converts and builds lasting communities.', 'azia-addon'),
            ]
        );

        $this->end_controls_section();

        // Main Service Controls
        $this->start_controls_section(
            'main_service_section',
            [
                'label' => __('Main Service', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'main_service_icon',
            [
                'label' => __('Icon', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-camera',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $this->add_control(
            'main_service_label',
            [
                'label' => __('Label Text', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Most Popular', 'azia-addon'),
            ]
        );

        $this->add_control(
            'main_service_title',
            [
                'label' => __('Title', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Content Creation & Visual Storytelling', 'azia-addon'),
            ]
        );

        $this->add_control(
            'main_service_description',
            [
                'label' => __('Description', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Captivate your audience with stunning visuals, engaging videos, and strategic storytelling that showcases your brand\'s unique personality and value proposition.', 'azia-addon'),
            ]
        );

        $this->add_control(
            'portfolio_button_text',
            [
                'label' => __('Portfolio Button Text', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('View Content Portfolio', 'azia-addon'),
            ]
        );

        $this->add_control(
            'portfolio_button_url',
            [
                'label' => __('Portfolio Button URL', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'azia-addon'),
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $this->add_control(
            'learn_more_text',
            [
                'label' => __('Learn More Text', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Learn more', 'azia-addon'),
            ]
        );

        $this->add_control(
            'learn_more_url',
            [
                'label' => __('Learn More URL', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'azia-addon'),
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $this->end_controls_section();

        // Service Features Repeater
        $this->start_controls_section(
            'service_features_section',
            [
                'label' => __('Service Features', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'feature_icon',
            [
                'label' => __('Icon', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-images',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $repeater->add_control(
            'feature_title',
            [
                'label' => __('Title', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Professional Photography', 'azia-addon'),
            ]
        );

        $repeater->add_control(
            'feature_description',
            [
                'label' => __('Description', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Brand-aligned visual content for all platforms', 'azia-addon'),
            ]
        );

        $this->add_control(
            'service_features',
            [
                'label' => __('Features', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'feature_icon' => [
                            'value' => 'fas fa-images',
                            'library' => 'fa-solid',
                        ],
                        'feature_title' => __('Professional Photography', 'azia-addon'),
                        'feature_description' => __('Brand-aligned visual content for all platforms', 'azia-addon'),
                    ],
                    [
                        'feature_icon' => [
                            'value' => 'fas fa-video',
                            'library' => 'fa-solid',
                        ],
                        'feature_title' => __('Video Production', 'azia-addon'),
                        'feature_description' => __('Short-form & long-form video content', 'azia-addon'),
                    ],
                    [
                        'feature_icon' => [
                            'value' => 'fas fa-pen-fancy',
                            'library' => 'fa-solid',
                        ],
                        'feature_title' => __('Copywriting', 'azia-addon'),
                        'feature_description' => __('Compelling captions & storytelling', 'azia-addon'),
                    ],
                    [
                        'feature_icon' => [
                            'value' => 'fas fa-paint-brush',
                            'library' => 'fa-solid',
                        ],
                        'feature_title' => __('Graphic Design', 'azia-addon'),
                        'feature_description' => __('Custom graphics & branded templates', 'azia-addon'),
                    ],
                ],
                'title_field' => '{{{ feature_title }}}',
            ]
        );

        $this->end_controls_section();

        // Secondary Service 1
        $this->start_controls_section(
            'secondary_service_1',
            [
                'label' => __('Secondary Service 1', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'secondary_1_icon',
            [
                'label' => __('Icon', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-palette',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $this->add_control(
            'secondary_1_number',
            [
                'label' => __('Number', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('02', 'azia-addon'),
            ]
        );

        $this->add_control(
            'secondary_1_title',
            [
                'label' => __('Title', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Brand Visual Identity', 'azia-addon'),
            ]
        );

        $this->add_control(
            'secondary_1_description',
            [
                'label' => __('Description', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Develop a cohesive visual style that instantly communicates your brand values across all platforms.', 'azia-addon'),
            ]
        );

        $this->add_control(
            'secondary_1_link_text',
            [
                'label' => __('Link Text', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Explore Services', 'azia-addon'),
            ]
        );

        $this->add_control(
            'secondary_1_link_url',
            [
                'label' => __('Link URL', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'azia-addon'),
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $this->end_controls_section();

        // Secondary Service 2
        $this->start_controls_section(
            'secondary_service_2',
            [
                'label' => __('Secondary Service 2', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'secondary_2_icon',
            [
                'label' => __('Icon', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-chart-line',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $this->add_control(
            'secondary_2_number',
            [
                'label' => __('Number', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('03', 'azia-addon'),
            ]
        );

        $this->add_control(
            'secondary_2_title',
            [
                'label' => __('Title', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Performance Metrics', 'azia-addon'),
            ]
        );

        $this->add_control(
            'metric_1_label',
            [
                'label' => __('Metric 1 Label', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Engagement Rate', 'azia-addon'),
            ]
        );

        $this->add_control(
            'metric_1_value',
            [
                'label' => __('Metric 1 Value', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('143%', 'azia-addon'),
            ]
        );

        $this->add_control(
            'metric_1_percentage',
            [
                'label' => __('Metric 1 Percentage', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 85,
                ],
            ]
        );

        $this->add_control(
            'metric_2_label',
            [
                'label' => __('Metric 2 Label', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Follower Growth', 'azia-addon'),
            ]
        );

        $this->add_control(
            'metric_2_value',
            [
                'label' => __('Metric 2 Value', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('89%', 'azia-addon'),
            ]
        );

        $this->add_control(
            'metric_2_percentage',
            [
                'label' => __('Metric 2 Percentage', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 65,
                ],
            ]
        );

        $this->add_control(
            'secondary_2_link_text',
            [
                'label' => __('Link Text', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('View Case Studies', 'azia-addon'),
            ]
        );

        $this->add_control(
            'secondary_2_link_url',
            [
                'label' => __('Link URL', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'azia-addon'),
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $this->end_controls_section();

        // Platform Services
        $this->start_controls_section(
            'platform_services_section',
            [
                'label' => __('Platform Services', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $platforms_repeater = new \Elementor\Repeater();

        $platforms_repeater->add_control(
            'platform_icon',
            [
                'label' => __('Icon', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fab fa-instagram',
                    'library' => 'fa-brands',
                ],
            ]
        );

        $platforms_repeater->add_control(
            'platform_name',
            [
                'label' => __('Platform Name', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Instagram', 'azia-addon'),
            ]
        );

        $platforms_repeater->add_control(
            'platform_subtitle',
            [
                'label' => __('Subtitle', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Feed, Stories, Reels', 'azia-addon'),
            ]
        );

        $platforms_repeater->add_control(
            'platform_description',
            [
                'label' => __('Description', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Strategic content planning, carousel designs, engaging Reels, and story sequences that drive engagement and growth.', 'azia-addon'),
            ]
        );

        $platforms_repeater->add_control(
            'platform_color',
            [
                'label' => __('Platform Color', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'linear-gradient(90deg, #833AB4, #FD1D1D, #FCB045)',
            ]
        );

        $this->add_control(
            'platforms',
            [
                'label' => __('Platforms', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $platforms_repeater->get_controls(),
                'default' => [
                    [
                        'platform_icon' => [
                            'value' => 'fab fa-instagram',
                            'library' => 'fa-brands',
                        ],
                        'platform_name' => __('Instagram', 'azia-addon'),
                        'platform_subtitle' => __('Feed, Stories, Reels', 'azia-addon'),
                        'platform_description' => __('Strategic content planning, carousel designs, engaging Reels, and story sequences that drive engagement and growth.', 'azia-addon'),
                        'platform_color' => 'linear-gradient(90deg, #833AB4, #FD1D1D, #FCB045)',
                    ],
                    [
                        'platform_icon' => [
                            'value' => 'fab fa-tiktok',
                            'library' => 'fa-brands',
                        ],
                        'platform_name' => __('TikTok', 'azia-addon'),
                        'platform_subtitle' => __('Trending Content & Challenges', 'azia-addon'),
                        'platform_description' => __('Viral-worthy short videos, trending audio utilization, and challenge participation strategies for maximum reach.', 'azia-addon'),
                        'platform_color' => '#000000',
                    ],
                    [
                        'platform_icon' => [
                            'value' => 'fab fa-youtube',
                            'library' => 'fa-brands',
                        ],
                        'platform_name' => __('YouTube', 'azia-addon'),
                        'platform_subtitle' => __('Long-form & Shorts', 'azia-addon'),
                        'platform_description' => __('Professional video production, SEO-optimized content, and strategic publishing schedules for channel growth.', 'azia-addon'),
                        'platform_color' => '#FF0000',
                    ],
                ],
                'title_field' => '{{{ platform_name }}}',
            ]
        );

        $this->end_controls_section();

        // CTA Section
        $this->start_controls_section(
            'cta_section',
            [
                'label' => __('Call to Action', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'cta_title',
            [
                'label' => __('CTA Title', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Ready to elevate your social media presence?', 'azia-addon'),
            ]
        );

        $this->add_control(
            'cta_description',
            [
                'label' => __('CTA Description', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Let\'s create a customized strategy that aligns with your unique brand voice and business goals.', 'azia-addon'),
            ]
        );

        $this->add_control(
            'cta_button_text',
            [
                'label' => __('Button Text', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Schedule a Free Strategy Call', 'azia-addon'),
            ]
        );

        $this->add_control(
            'cta_button_url',
            [
                'label' => __('Button URL', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'azia-addon'),
                'default' => [
                    'url' => '#contact',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tabs
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Colors', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );


        // Primary Color
        $this->add_control(
            'primary_color',
            [
                'label' => esc_html__('Primary Color', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#0ea5e9',
                'selectors' => [],
                'global' => [
                    'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_PRIMARY
                ]
            ]
        );

        // Secondary Color
        $this->add_control(
            'secondary_color',
            [
                'label' => esc_html__('Secondary Color', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#6366f1',
                'selectors' => [],
                'global' => [
                    'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_SECONDARY
                ]
            ]
        );

        // Accent_color Color
        $this->add_control(
            'accent_color_color',
            [
                'label' => esc_html__('Accent_color Color', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#f6339a',
                'selectors' => [],
                'global' => [
                    'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_ACCENT
                ]
            ]
        );
        $this->end_controls_section();
    }

    /**
     * Render widget output on the frontend.
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        // Colors
        $primary_color = !empty($settings['primary_color']) ? $settings['primary_color'] : '#0ea5e9'; //sky
        $secondary_color = !empty($settings['secondary_color']) ? $settings['secondary_color'] : '#6366f1'; //indigo
        $accent_color = !empty($settings['accent_color_color']) ? $settings['accent_color_color'] : '#f6339a'; //pink

        // Get URLs with proper formats
        $portfolio_button_url = !empty($settings['portfolio_button_url']['url']) ? $settings['portfolio_button_url']['url'] : '#';
        $learn_more_url = !empty($settings['learn_more_url']['url']) ? $settings['learn_more_url']['url'] : '#';
        $secondary_1_url = !empty($settings['secondary_1_link_url']['url']) ? $settings['secondary_1_link_url']['url'] : '#';
        $secondary_2_url = !empty($settings['secondary_2_link_url']['url']) ? $settings['secondary_2_link_url']['url'] : '#';
        $cta_url = !empty($settings['cta_button_url']['url']) ? $settings['cta_button_url']['url'] : '#contact';

        // Get target attributes
        $portfolio_button_target = !empty($settings['portfolio_button_url']['is_external']) ? ' target="_blank"' : '';
        $learn_more_target = !empty($settings['learn_more_url']['is_external']) ? ' target="_blank"' : '';
        $secondary_1_target = !empty($settings['secondary_1_link_url']['is_external']) ? ' target="_blank"' : '';
        $secondary_2_target = !empty($settings['secondary_2_link_url']['is_external']) ? ' target="_blank"' : '';
        $cta_target = !empty($settings['cta_button_url']['is_external']) ? ' target="_blank"' : '';

        // Get slider values
        $metric_1_percentage = isset($settings['metric_1_percentage']['size']) ? $settings['metric_1_percentage']['size'] : 85;
        $metric_2_percentage = isset($settings['metric_2_percentage']['size']) ? $settings['metric_2_percentage']['size'] : 65;
?>

        <!-- Enhanced Services Section with Advanced Visual Elements -->
        <section class="service-section  py-24 bg-gray-50 relative overflow-hidden" style="--primary-color: <?php echo esc_attr($primary_color); ?>; --secondary-color: <?php echo esc_attr($secondary_color); ?>; --accent-color: <?php echo esc_attr($accent_color); ?>;" id="services">
            <!-- Advanced background elements -->
            <div class="absolute inset-0 -z-10 overflow-hidden">
                <!-- Layered gradient meshes -->
                <div class="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-white via-gray-50 to-white opacity-70"></div>
                <div class="absolute -top-96 -right-96 w-[800px] h-[800px] rounded-full blur-3xl opacity-60" style="background: linear-gradient(to bottom right, <?php echo esc_attr(adjust_color_brightness($primary_color, 50, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($accent_color, 50, 1)); ?>);"></div>
                <div class="absolute -bottom-64 -left-64 w-[600px] h-[600px] rounded-full blur-3xl opacity-50" style="background: linear-gradient(to top right, <?php echo esc_attr(adjust_color_brightness($accent_color, 50, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($primary_color, 50, 1)); ?>);"></div>

                <!-- Animated grid pattern -->
                <div class="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMwLTkuOTQtOC4wNi0xOC0xOC0xOHY2YzYuNjMgMCAxMiA1LjM3IDEyIDEyaC0xMnY2aDEydjEyaDZ2LTEyaDEydjZoLTEydjEyYzAgNi42My01LjM3IDEyLTEyIDEydjZjOS45NCAwIDE4LTguMDYgMTgtMTh2LTEyaDEyYzAgOS45NCA4LjA2IDE4IDE4IDE4djZjLTEzLjI1NSAwLTI0LTEwLjc0NS0yNC0yNGgtMTJ2LTEyeiIgZmlsbD0iI2VlZWVmZiIvPjwvZz48L3N2Zz4=')]"
                    style="opacity: 0.07; animation: parallaxBg 50s linear infinite;"></div>
            </div>

            <!-- Interactive floating elements -->
            <div class="absolute top-1/4 left-10 w-8 h-8 rounded-lg opacity-20 floating" style="background-color: <?php echo esc_attr(adjust_color_brightness($primary_color, 300, 1)); ?>; transform-origin: center; animation: floatAndRotate 8s ease-in-out infinite;"></div>
            <div class="absolute top-1/3 right-16 w-6 h-6 border-2 rounded-full opacity-30 floating floating-delay-2" style="border-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 300, 1)); ?>; transform-origin: center; animation: floatAndRotate 7s ease-in-out infinite reverse;"></div>
            <div class="absolute bottom-1/4 left-1/4 w-10 h-10 rounded-lg opacity-20 floating floating-delay-3"
                style="background-color: <?php echo esc_attr(adjust_color_brightness($accent_color, 200, 1)); ?>; transform-origin: center; animation: floatAndRotate 9s ease-in-out infinite;"></div>

            <div class="container mx-auto px-6 relative z-10">
                <!-- Advanced Section Header with 3D effect -->
                <div class="text-center mb-20 max-w-3xl mx-auto perspective-element">
                    <!-- Advanced pill badge with pulse animation -->
                    <div class="inline-block px-4 py-1.5 backdrop-blur-md rounded-full text-sm font-semibold mb-5 shadow-sm badge-animation relative" style="background: linear-gradient(to right, <?php echo esc_attr(adjust_color_brightness($secondary_color, 100, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($primary_color, 100, 1)); ?>); color: <?php echo esc_attr($secondary_color); ?>;">
                        <div class="absolute inset-0 rounded-full opacity-0 badge-pulse" style="background: linear-gradient(to right, <?php echo esc_attr(adjust_color_brightness($secondary_color, 200, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($primary_color, 200, 1)); ?>);"></div>
                        <span class="flex items-center relative z-10">
                            <span class="w-2 h-2 rounded-full mr-2 pulse-ring" style="background-color: <?php echo esc_attr($secondary_color); ?>;"></span>
                            <span><?php echo esc_html($settings['badge_text']); ?></span>
                        </span>
                    </div>

                    <h2 class="text-4xl md:text-5xl font-bold mb-6 tracking-tight perspective-title fade-in-effect">
                        <?php echo wp_kses_post($settings['title']); ?>
                    </h2>

                    <p class="text-lg text-gray-600 max-w-2xl mx-auto fade-in-effect effect-1">
                        <?php echo wp_kses_post($settings['description']); ?>
                    </p>
                </div>

                <!-- Advanced 3D Services Showcase -->
                <div class="relative service-showcase perspective-3000">
                    <!-- Content Creation Tab (Active) -->
                    <div class="service-tab-content active ">
                        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 relative fade-in-effect">
                            <!-- Main Visual -->
                            <div class="md:col-span-2 p-10 rounded-3xl text-white relative tilt-card h-full" style="background: linear-gradient(to bottom right, <?php echo esc_attr($primary_color); ?>, <?php echo esc_attr($secondary_color); ?>);">
                                <!-- Decorative elements -->
                                <div class="absolute top-0 right-0 w-full h-full overflow-hidden rounded-3xl">
                                    <div class="absolute -right-16 -top-16 w-64 h-64 bg-white opacity-10 rounded-full"></div>
                                    <div class="absolute right-16 bottom-16 w-24 h-24 bg-white opacity-10 rounded-full"></div>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" class="absolute -right-20 -bottom-20 w-96 h-96 text-white opacity-5">
                                        <path fill="currentColor" d="M39.2,-65.8C52,-60.3,64.8,-52.4,72.5,-41C80.2,-29.5,82.9,-14.8,81.7,-0.7C80.6,13.3,75.6,26.5,67.5,37.4C59.4,48.3,48.2,56.8,36,63.1C23.7,69.4,10.4,73.4,-2.1,76.6C-14.5,79.8,-29,82.2,-42,77.5C-55,72.8,-66.5,61.1,-73.9,47.1C-81.2,33.1,-84.4,16.6,-83.1,0.8C-81.8,-15,-76,-30,-67.9,-43.6C-59.8,-57.2,-49.5,-69.5,-36.8,-74.8C-24.1,-80.1,-9.1,-78.3,2.9,-83.2C14.8,-88,29.6,-99.5,39.2,-65.8Z" transform="translate(100 100)" />
                                    </svg>
                                </div>

                                <div class="relative z-10 flex flex-col h-full">
                                    <div class="flex items-start">

                                        <span class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-md text-white mb-6 rotated-element">
                                            <i class="<?php echo esc_attr($settings['main_service_icon']['value']); ?> text-3xl"></i>
                                        </span>

                                        <div class="ml-4 mt-2">
                                            <span class="px-4 py-1 rounded-full bg-white/20 backdrop-blur-md text-sm font-medium">
                                                <?php echo esc_html($settings['main_service_label']); ?>
                                            </span>
                                        </div>
                                    </div>

                                    <h3 class="text-3xl font-bold mb-6 mt-2"><?php echo esc_html($settings['main_service_title']); ?></h3>

                                    <p class="text-white/80 text-lg mb-8 max-w-xl">
                                        <?php echo esc_html($settings['main_service_description']); ?>
                                    </p>

                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8 flex-grow">
                                        <?php
                                        foreach ($settings['service_features'] as $feature) :
                                        ?>
                                            <div class="flex items-start backdrop-blur-sm bg-white/10 rounded-xl p-4">
                                                <div class="w-10 h-10 rounded-lg bg-white/20 flex items-center justify-center text-white mt-1 mr-4">
                                                    <i class="<?php echo esc_attr($feature['feature_icon']['value']); ?>"></i>
                                                </div>
                                                <div>
                                                    <h4 class="font-semibold text-lg"><?php echo esc_html($feature['feature_title']); ?></h4>
                                                    <p class="text-white/70 mt-1"><?php echo esc_html($feature['feature_description']); ?></p>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>

                                    <div class="mt-auto flex flex-wrap items-center gap-4">
                                        <a href="<?php echo esc_url($portfolio_button_url); ?>" <?php echo $portfolio_button_target; ?> class="px-7 py-3.5 bg-white font-semibold rounded-full hover:shadow-lg transition-all glow-button inline-flex items-center group" style="color: <?php echo esc_attr($secondary_color); ?>; hover:shadow-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 900, 0.2)); ?>;">
                                            <span><?php echo esc_html($settings['portfolio_button_text']); ?></span>
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ml-2 transition-transform duration-300 group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                            </svg>
                                        </a>

                                        <a href="<?php echo esc_url($learn_more_url); ?>" <?php echo $learn_more_target; ?> class="inline-flex items-center text-white font-medium group">
                                            <span><?php echo esc_html($settings['learn_more_text']); ?></span>
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ml-1 transition-transform duration-300 group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <!-- Right Side Stack -->
                            <div class="flex flex-col gap-8">
                                <!-- Top Card -->
                                <div class="modern-card p-8 rounded-3xl hover-up tilt-card-sm relative bg-white h-1/2">
                                    <!-- Decorative element -->
                                    <div class="absolute top-0 right-0 w-20 h-20 rounded-bl-3xl rounded-tr-3xl -z-10" style="background-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>;"></div>

                                    <div class="flex items-center justify-between mb-6">
                                        <span class="inline-flex items-center justify-center w-12 h-12 rounded-xl mb-2 rotated-element" style="background-color: <?php echo esc_attr(adjust_color_brightness($primary_color, 100, 1)); ?>; color: <?php echo esc_attr($primary_color); ?>;">
                                            <i class="<?php echo esc_attr($settings['secondary_1_icon']['value']); ?>"></i>
                                        </span>
                                        <span class="text-sm font-medium text-gray-400"><?php echo esc_html($settings['secondary_1_number']); ?></span>
                                    </div>

                                    <h3 class="text-xl font-bold text-gray-800 mb-3"><?php echo esc_html($settings['secondary_1_title']); ?></h3>

                                    <p class="text-gray-600 mb-6">
                                        <?php echo esc_html($settings['secondary_1_description']); ?>
                                    </p>

                                    <a href="<?php echo esc_url($secondary_1_url); ?>" <?php echo $secondary_1_target; ?> class="font-medium flex items-center transition-colors group" style="color: <?php echo esc_attr($primary_color); ?>; hover:color: <?php echo esc_attr($secondary_color); ?>;">
                                        <?php echo esc_html($settings['secondary_1_link_text']); ?>
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 ml-1 transition-transform duration-300 group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                        </svg>
                                    </a>
                                </div>

                                <!-- Bottom Card -->
                                <div class="p-8 rounded-3xl hover-up tilt-card-sm relative overflow-hidden h-1/2 text-white" style="background: linear-gradient(to bottom right, <?php echo esc_attr($accent_color); ?>, <?php echo esc_attr($secondary_color); ?>);">
                                    <!-- Decorative patterns -->
                                    <div class="absolute -right-8 -bottom-8 w-32 h-32 bg-white rounded-full opacity-10"></div>
                                    <div class="absolute right-8 top-8 w-10 h-10 bg-white rounded-full opacity-10"></div>

                                    <div class="relative z-10">
                                        <div class="flex items-center justify-between mb-6">
                                            <span class="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-white/20 text-white mb-2 backdrop-blur-sm rotated-element">
                                                <i class="<?php echo esc_attr($settings['secondary_2_icon']['value']); ?>"></i>
                                            </span>
                                            <span class="text-sm font-medium text-white/60"><?php echo esc_html($settings['secondary_2_number']); ?></span>
                                        </div>

                                        <h3 class="text-xl font-bold text-white mb-3"><?php echo esc_html($settings['secondary_2_title']); ?></h3>

                                        <div class="space-y-3 mb-3">
                                            <div class="flex justify-between items-center">
                                                <span class="text-white/80 text-sm"><?php echo esc_html($settings['metric_1_label']); ?></span>
                                                <span class="text-white font-medium">+<?php echo esc_html($settings['metric_1_value']); ?></span>
                                            </div>
                                            <div class="w-full h-1.5 bg-white/20 rounded-full overflow-hidden">
                                                <div class="h-full w-[<?php echo esc_attr($metric_1_percentage); ?>%] bg-white rounded-full"></div>
                                            </div>

                                            <div class="flex justify-between items-center mt-2">
                                                <span class="text-white/80 text-sm"><?php echo esc_html($settings['metric_2_label']); ?></span>
                                                <span class="text-white font-medium">+<?php echo esc_html($settings['metric_2_value']); ?></span>
                                            </div>
                                            <div class="w-full h-1.5 bg-white/20 rounded-full overflow-hidden">
                                                <div class="h-full w-[<?php echo esc_attr($metric_2_percentage); ?>%] bg-white rounded-full"></div>
                                            </div>
                                        </div>

                                        <a href="<?php echo esc_url($secondary_2_url); ?>" <?php echo $secondary_2_target; ?> class="text-white font-medium flex items-center group">
                                            <?php echo esc_html($settings['secondary_2_link_text']); ?>
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 ml-1 transition-transform duration-300 group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Bottom Services Row -->
                        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8 fade-in-effect effect-1">
                            <!-- Platform Expertise Cards -->
                            <?php foreach ($settings['platforms'] as $index => $platform) : ?>
                                <div class="modern-card p-6 hover-up relative overflow-hidden">
                                    <!-- Brand color bar -->
                                    <div class="absolute top-0 left-0 w-full h-1" style="background: <?php echo esc_attr($platform['platform_color']); ?>"></div>

                                    <div class="flex items-center gap-4">
                                        <div class="w-12 h-12 rounded-full flex items-center justify-center text-white" style="background: <?php echo esc_attr($platform['platform_color']); ?>">
                                            <i class="<?php echo esc_attr($platform['platform_icon']['value']); ?>"></i>

                                        </div>
                                        <div>
                                            <h3 class="font-bold text-gray-800"><?php echo esc_html($platform['platform_name']); ?></h3>
                                            <p class="text-sm text-gray-500"><?php echo esc_html($platform['platform_subtitle']); ?></p>
                                        </div>
                                    </div>

                                    <div class="mt-4 pl-16">
                                        <p class="text-gray-600 text-sm">
                                            <?php echo esc_html($platform['platform_description']); ?>
                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Services CTA -->
                <div class="mt-16 md:mt-24 mb-10 relative fade-in-effect">
                    <div class="modern-card overflow-hidden relative p-10 md:p-12 rounded-3xl hover-up">
                        <!-- Background gradient with animated grain texture -->
                        <div class="absolute inset-0 overflow-hidden" style="background: linear-gradient(to right, <?php echo esc_attr(adjust_color_brightness($primary_color, 500, 0.95)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 600, 0.95)); ?>);">
                            <div class="absolute inset-0 opacity-20" style="background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMDAiIGhlaWdodD0iMzAwIj48ZmlsdGVyIGlkPSJhIiB4PSIwIiB5PSIwIj48ZmVUdXJidWxlbmNlIGJhc2VGcmVxdWVuY3k9Ii43NSIgc3RpdGNoVGlsZXM9InN0aXRjaCIgdHlwZT0iZnJhY3RhbE5vaXNlIi8+PGZlQ29sb3JNYXRyaXggdHlwZT0ic2F0dXJhdGUiIHZhbHVlcz0iMCIvPjwvZmlsdGVyPjxwYXRoIGQ9Ik0wIDBoMzAwdjMwMEgweiIgZmlsdGVyPSJ1cmwoI2EpIiBvcGFjaXR5PSIuMDUiLz48L3N2Zz4=');"></div>
                        </div>

                        <!-- Decorative elements -->
                        <div class="absolute -top-20 -right-20 w-64 h-64 bg-white opacity-10 rounded-full"></div>
                        <div class="absolute bottom-10 left-10 w-32 h-32 bg-white opacity-10 rounded-full"></div>

                        <div class="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
                            <div>
                                <h3 class="text-2xl md:text-3xl font-bold text-white mb-4"><?php echo esc_html($settings['cta_title']); ?></h3>
                                <p class="text-white/80 max-w-xl">
                                    <?php echo esc_html($settings['cta_description']); ?>
                                </p>
                            </div>
                            <a href="<?php echo esc_url($cta_url); ?>" <?php echo $cta_target; ?> class="px-8 py-4 bg-white font-semibold rounded-full hover:shadow-lg transition-all w-full md:w-auto text-center magnetic-btn group" style="color: <?php echo esc_attr($secondary_color); ?>; hover:shadow-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 900, 0.2)); ?>;">
                                <span class="flex items-center justify-center">
                                    <?php echo esc_html($settings['cta_button_text']); ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ml-2 transition-transform duration-300 group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                    </svg>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Decorative wave divider -->
            <div class="absolute bottom-0 left-0 w-full">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 100" class="text-white">
                    <path fill="currentColor" fill-opacity="1" d="M0,64L60,58.7C120,53,240,43,360,53.3C480,64,600,96,720,96C840,96,960,64,1080,58.7C1200,53,1320,75,1380,85.3L1440,96L1440,100L1380,100C1320,100,1200,100,1080,100C960,100,840,100,720,100C600,100,480,100,360,100C240,100,120,100,60,100L0,100Z"></path>
                </svg>
            </div>
        </section>
        <!-- Add JavaScript for interactive elements -->
        <script>
            document.addEventListener('DOMContentLoaded', function() {



                // Add magnetic effect to buttons
                const magneticBtns = document.querySelectorAll('.magnetic-btn');
                if (magneticBtns.length > 0) {
                    magneticBtns.forEach(btn => {
                        btn.addEventListener('mousemove', function(e) {
                            const rect = this.getBoundingClientRect();
                            const x = e.clientX - rect.left;
                            const y = e.clientY - rect.top;

                            const centerX = rect.width / 2;
                            const centerY = rect.height / 2;

                            const moveX = (x - centerX) / 10;
                            const moveY = (y - centerY) / 10;

                            this.style.transform = `translateX(${moveX}px) translateY(${moveY}px)`;
                        });

                        btn.addEventListener('mouseleave', function() {
                            this.style.transform = 'translateX(0) translateY(0)';
                        });
                    });
                }
            });
        </script>
<?php
    }
}
