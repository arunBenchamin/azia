<?php

/**
 * Modern Portfolio Widget for Elementor
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

class Elementor_Portfolio_Widget extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'azia_modern_portfolio';
    }

    public function get_title()
    {
        return esc_html__('Portfolio', 'azia-addon');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['azia'];
    }

    public function get_keywords()
    {
        return ['portfolio', 'projects', 'grid', 'filter'];
    }

    protected function register_controls()
    {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'badge_text',
            [
                'label' => esc_html__('Badge Text', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Featured Work', 'azia-addon'),
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Creative Portfolio', 'azia-addon'),
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => esc_html__('Description', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Explore a selection of strategic social media campaigns and content creation projects that have driven significant growth and engagement for our clients.', 'azia-addon'),
            ]
        );

        // Replace the 'show_load_more' and 'load_more_text' controls with pagination controls
        $this->add_control(
            'show_pagination',
            [
                'label' => esc_html__('Show Pagination', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'azia-addon'),
                'label_off' => esc_html__('Hide', 'azia-addon'),
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'pagination_alignment',
            [
                'label' => esc_html__('Pagination Alignment', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'start' => [
                        'title' => esc_html__('Left', 'azia-addon'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'azia-addon'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'end' => [
                        'title' => esc_html__('Right', 'azia-addon'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'condition' => [
                    'show_pagination' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .portfolio-pagination' => 'display: flex; justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Query Section
        $this->start_controls_section(
            'query_section',
            [
                'label' => esc_html__('Query', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => esc_html__('Posts Per Page', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 5,
                'min' => 1,
                'max' => 20,
            ]
        );

        $this->add_control(
            'categories',
            [
                'label' => esc_html__('Categories', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'options' => $this->get_portfolio_categories(),
                'multiple' => true,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => esc_html__('Order By', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'date',
                'options' => [
                    'date' => esc_html__('Date', 'azia-addon'),
                    'title' => esc_html__('Title', 'azia-addon'),
                    'menu_order' => esc_html__('Menu Order', 'azia-addon'),
                    'rand' => esc_html__('Random', 'azia-addon'),
                ],
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => esc_html__('Order', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'DESC',
                'options' => [
                    'DESC' => esc_html__('Descending', 'azia-addon'),
                    'ASC' => esc_html__('Ascending', 'azia-addon'),
                ],
            ]
        );

        $this->end_controls_section();



        // Style Tabs
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Colors', 'your-plugin-text-domain'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
      // Primary Color
      $this->add_control(
        'primary_color',
        [
            'label' => esc_html__('Primary Color', 'azia-addon'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#0ea5e9',
            'selectors' => [],
            'global' => [
                'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_PRIMARY
            ]
        ]
    );

    // Secondary Color
    $this->add_control(
        'secondary_color',
        [
            'label' => esc_html__('Secondary Color', 'azia-addon'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#6366f1',
            'selectors' => [],
            'global' => [
                'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_SECONDARY
            ]
        ]
    );

    // Accent_color Color
    $this->add_control(
        'accent_color_color',
        [
            'label' => esc_html__('Accent_color Color', 'azia-addon'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#f6339a',
            'selectors' => [],
            'global' => [
                'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_ACCENT
            ]
        ]
    );
    $this->end_controls_section();


        // Style Section - Cards
        $this->start_controls_section(
            'style_cards_section',
            [
                'label' => esc_html__('Card Style', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_border_radius',
            [
                'label' => esc_html__('Card Border Radius', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 24,
                ],
                'selectors' => [
                    '{{WRAPPER}} .modern-card' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'card_box_shadow',
                'label' => esc_html__('Card Shadow', 'azia-addon'),
                'selector' => '{{WRAPPER}} .modern-card',
            ]
        );

        $this->end_controls_section();
    }

    private function get_portfolio_categories()
    {
        $terms = get_terms([
            'taxonomy' => 'portfolio_category',
            'hide_empty' => true,
        ]);

        if (empty($terms) || is_wp_error($terms)) {
            return [];
        }

        $options = [];
        foreach ($terms as $term) {
            $options[$term->term_id] = $term->name;
        }

        return $options;
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        // Colors
        $primary_color = !empty($settings['primary_color']) ? $settings['primary_color'] : '#0ea5e9'; //sky
        $secondary_color = !empty($settings['secondary_color']) ? $settings['secondary_color'] : '#6366f1'; //indigo
        $accent_color = !empty($settings['accent_color_color']) ? $settings['accent_color_color'] : '#f6339a'; //pink
        $unique_id = 'portfolio-' . uniqid();


        $paged = 1;
        if (get_query_var('paged')) {
            $paged = get_query_var('paged');
        } elseif (get_query_var('page')) {
            $paged = get_query_var('page');
        } elseif (isset($_GET['portfolio-page'])) {
            $paged = intval($_GET['portfolio-page']);
        }

        // Query Arguments
        $args = [
            'post_type' => 'portfolio_project',
            'posts_per_page' => $settings['posts_per_page'],
            'paged' => $paged, // Add this line
            'orderby' => $settings['orderby'],
            'order' => $settings['order'],
        ];

        // Add category filter if selected
        if (!empty($settings['categories'])) {
            $args['tax_query'] = [
                [
                    'taxonomy' => 'portfolio_category',
                    'field' => 'term_id',
                    'terms' => $settings['categories'],
                ],
            ];
        }

        $query = new \WP_Query($args);

        $terms = get_terms([
            'taxonomy' => 'portfolio_category',
            'hide_empty' => true, // Only get categories that have posts
        ]);


        $all_categories = [];
        foreach ($terms as $term) {
            $all_categories[$term->term_id] = $term->name;
        }
?>


        <!-- Portfolio Section -->
        <section class="py-24 bg-white relative overflow-hidden portfolio-section" id="portfolio" data-posts-per-page="<?php echo esc_attr($settings['posts_per_page']); ?>"
            data-categories="<?php echo esc_attr(json_encode($settings['categories'])); ?>"
            data-orderby="<?php echo esc_attr($settings['orderby']); ?>"
            data-order="<?php echo esc_attr($settings['order']); ?>" style="--primary-color: <?php echo esc_attr($primary_color); ?>; --secondary-color: <?php echo esc_attr($secondary_color); ?>; --accent-color: <?php echo esc_attr($accent_color); ?>;">
            <!-- Background elements -->
            <div class="absolute inset-0 -z-10 overflow-hidden">
                <!-- Subtle grid background pattern -->
                <div class="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0wIDBoNjB2NjBIMHoiLz48cGF0aCBkPSJNMzAgMzBoMzB2MzBIMzB6IiBzdHJva2U9IiNmMGYwZjAiIHN0cm9rZS13aWR0aD0iMiIvPjxwYXRoIGQ9Ik0wIDMwaDMwdjMwSDB6IiBzdHJva2U9IiNmMGYwZjAiIHN0cm9rZS13aWR0aD0iMiIvPjxwYXRoIGQ9Ik0wIDBoMzB2MzBIMHoiIHN0cm9rZT0iI2YwZjBmMCIgc3Ryb2tlLXdpZHRoPSIyIi8+PHBhdGggZD0iTTMwIDBoMzB2MzBIMzB6IiBzdHJva2U9IiNmMGYwZjAiIHN0cm9rZS13aWR0aD0iMiIvPjwvZz48L3N2Zz4=')]" style="opacity: 0.3;"></div>
            </div>

            <!-- Floating elements -->
            <div class="absolute top-40 right-20 w-8 h-8 rounded-full opacity-30 floating" style="background-color: <?php echo esc_attr(adjust_color_brightness($accent_color, 200, 1)); ?>;"></div>
            <div class="absolute bottom-20 left-40 w-6 h-6 rounded-full opacity-30 floating floating-delay-2" style="background-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 200, 1)); ?>;"></div>

            <div class="container mx-auto px-6 relative z-10 portfolio-items" id="<?php echo esc_attr($unique_id); ?>">
                <!-- Section Header -->
                <div class="text-center mb-16 max-w-3xl mx-auto fade-in-up">
                    <!-- Badge -->
                    <?php if (!empty($settings['badge_text'])) : ?>
                        <div class="inline-block px-4 py-1.5 backdrop-blur-md rounded-full text-sm font-semibold mb-5 shadow-sm badge-animation relative" style="background: linear-gradient(to right, <?php echo esc_attr(adjust_color_brightness($accent_color, 100, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 100, 1)); ?>); color: <?php echo esc_attr($accent_color); ?>;">
                            <div class="absolute inset-0 rounded-full opacity-0 badge-pulse" style="background: linear-gradient(to right, <?php echo esc_attr(adjust_color_brightness($accent_color, 200, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 200, 1)); ?>);"></div>
                            <span class="flex items-center relative z-10">
                                <span class="w-2 h-2 rounded-full mr-2 pulse-ring" style="background-color: <?php echo esc_attr($accent_color); ?>;"></span>
                                <span><?php echo esc_html($settings['badge_text']); ?></span>
                            </span>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($settings['title'])) : ?>
                        <h2 class="text-4xl md:text-5xl font-bold mb-6 tracking-tight perspective-title fade-in-effect">
                            <?php
                            $title_parts = explode(' ', $settings['title']);
                            $last_word = array_pop($title_parts);
                            echo esc_html(implode(' ', $title_parts)) . ' ';
                            echo '<span class="gradient-text relative inline-block transform transition-all">' . esc_html($last_word) . '</span>';
                            ?>
                        </h2>
                    <?php endif; ?>

                    <?php if (!empty($settings['description'])) : ?>
                        <p class="text-lg text-gray-600 max-w-2xl mx-auto perspective-content fade-in-effect effect-1">
                            <?php echo esc_html($settings['description']); ?>
                        </p>
                    <?php endif; ?>
                </div>

                <!-- Portfolio Filter Navigation -->
                <?php if (!empty($all_categories)) : ?>
                    <div class="flex flex-wrap justify-center gap-4 mb-12 fade-in-effect effect-2">
                        <button type="button" class="filter-btn px-6 py-3 rounded-full border transition-all font-medium relative active bg-indigo-50 text-indigo-500" data-filter="all">
                            <span class="relative z-10"><?php echo esc_html__('All Projects', 'azia-addon'); ?></span>
                        </button>

                        <?php foreach ($all_categories as $id => $name) : ?>
                            <button type="button" class="filter-btn px-6 py-3 rounded-full text-gray-700 bg-white border border-gray-200 transition-all font-medium relative" style="hover:background-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>; hover:color: <?php echo esc_attr($secondary_color); ?>;" data-filter="<?php echo esc_attr($id); ?>">
                                <span class="relative z-10"><?php echo esc_html($name); ?></span>
                            </button>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <!-- Portfolio Grid -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 fade-in-effect">
                    <?php
                    if ($query->have_posts()) :
                        $counter = 0;
                        while ($query->have_posts()) :
                            $query->the_post();
                            $counter++;

                            // Get project details
                            $project_categories = get_the_terms(get_the_ID(), 'portfolio_category');
                            $cat_classes = [];
                            $category_name = '';

                            if (!empty($project_categories) && !is_wp_error($project_categories)) {
                                foreach ($project_categories as $category) {
                                    $cat_classes[] = 'cat-' . $category->term_id;
                                    if (empty($category_name)) {
                                        $category_name = $category->name;
                                    }
                                }
                            }

                            // Get project meta data
                            if (class_exists('\Elementor\Plugin') && class_exists('\Elementor\Core\Settings\Manager')) {
                                try {
                                    $page_settings_manager = \Elementor\Core\Settings\Manager::get_settings_managers('page');
                                    if ($page_settings_manager) {
                                        $page_settings_model = $page_settings_manager->get_model(get_the_ID());
                                        if ($page_settings_model) {
                                            $stat_label = $page_settings_model->get_settings('stat_label');
                                            $stat_icon = $page_settings_model->get_settings('stat_icon');
                                            $stats_list = [];
                                            $page_settings = $page_settings_model->get_settings();
                                            for ($i = 1; $i <= 3; $i++) {
                                                if (!empty($page_settings["stat_label_{$i}"])) {
                                                    $stats_list[] = [
                                                        'stat_icon'   => $page_settings["stat_icon_{$i}"] ?? null,
                                                        'stat_label'  => $page_settings["stat_label_{$i}"] ?? '',
                                                    ];
                                                }
                                            }
                                        }
                                    }
                                } catch (Exception $e) {
                                    // Silently handle any errors that might occur when accessing Elementor
                                    error_log('Elementor settings access error: ' . $e->getMessage());
                                }
                            }

                            // Check if it's a full-width item (every 4th item)
                            $full_width_class = ($counter % 4 === 0) ? 'lg:col-span-2' : '';
                    ?>

                            <!-- Portfolio Item <?php echo esc_attr($counter); ?> -->
                            <div class="modern-card rounded-3xl overflow-hidden hover-up group portfolio-item flex flex-col <?php echo esc_attr($full_width_class); ?> <?php echo esc_attr(implode(' ', $cat_classes)); ?>" data-project-id="<?php echo esc_attr(get_the_ID()); ?>">
                                <!-- Image Container with gradient overlay -->
                                <div class="h-80 relative overflow-hidden">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <?php the_post_thumbnail('large', ['class' => 'w-full !h-full object-cover transition-transform duration-700 group-hover:scale-110']); ?>
                                    <?php else : ?>
                                        <img src="<?php echo \Elementor\Utils::get_placeholder_image_src(); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" class="w-full !h-full object-cover transition-transform duration-700 group-hover:scale-110">
                                    <?php endif; ?>

                                    <!-- Gradient Overlay -->
                                    <div class="absolute inset-0 opacity-70 transition-opacity group-hover:opacity-90" style="background: linear-gradient(to top, <?php echo esc_attr(adjust_color_brightness($secondary_color, 900, 0.8)); ?>, transparent);"></div>

                                    <!-- Category Pill -->
                                    <?php if (!empty($category_name)) : ?>
                                        <div class="category-pill absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-medium bg-white/20 backdrop-blur-md text-white">
                                            <?php echo esc_html($category_name); ?>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Stats -->
                                    <div class="absolute bottom-6 left-6 right-6 flex flex-wrap gap-4">
                                        <div class="flex flex-wrap gap-8 pt-6">
                                            <?php

                                            foreach ($stats_list as $stat):
                                            ?>
                                                <div class="px-3 py-1.5 rounded-full text-xs font-medium bg-white/20 backdrop-blur-md text-white flex items-center">
                                                    <?php
                                                    if (!empty($stat['stat_icon']) && class_exists('\Elementor\Icons_Manager')) {
                                                    ?>
                                                        <i class="<?php echo esc_attr($stat['stat_icon']['value']); ?> mr-1.5"></i>
                                                    <?php
                                                    }
                                                    ?>
                                                    <span><?php echo esc_html($stat['stat_label']); ?></span>
                                                </div>
                                            <?php

                                            endforeach; ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Content -->
                                <div class="p-6 flex-1 flex flex-col justify-between">
                                    <h3 class="text-xl font-bold text-gray-800 mb-2"><?php the_title(); ?></h3>
                                    <p class="text-gray-600 mb-5">
                                        <?php
                                        if (!(empty($page_settings["page_description"]))) {
                                            echo $page_settings["page_description"];
                                        } else {
                                            echo wp_trim_words(get_the_excerpt(), 15, '...');
                                        }
                                        ?>
                                    </p>
                                    <div class="flex items-center justify-between">
                                        <button class="view-project-btn font-medium flex items-center text-sm transition-colors group" style="color: <?php echo esc_attr($secondary_color); ?>; hover:color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 600, 1)); ?>;" data-project-id="<?php echo esc_attr(get_the_ID()); ?>">
                                            <?php echo esc_html__('View Project', 'azia-addon'); ?>
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 ml-1 transition-transform duration-300 group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                            </div>

                    <?php
                        endwhile;
                        wp_reset_postdata();
                    endif;
                    ?>
                </div>
                <div class="mt-12 portfolio-pagination fade-in-effect">
                    <?php
                    // Pagination
                    if ($settings['show_pagination'] === 'yes' && $query->max_num_pages > 1) :
                        // Pass necessary variables to the template
                        $current_page = $paged;
                        $total_pages = $query->max_num_pages;

                        // Include the pagination template
                        include_once(dirname(__FILE__) . '/templates/portfolio-pagination.php');
                    endif;
                    ?>
                </div>
            </div>

            <!-- Decorative wave divider -->
            <div class="absolute bottom-0 left-0 w-full">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 100" class="text-gray-50">
                    <path fill="currentColor" fill-opacity="1" d="M0,64L60,58.7C120,53,240,43,360,53.3C480,64,600,96,720,96C840,96,960,64,1080,58.7C1200,53,1320,75,1380,85.3L1440,96L1440,100L1380,100C1320,100,1200,100,1080,100C960,100,840,100,720,100C600,100,480,100,360,100C240,100,120,100,60,100L0,100Z"></path>
                </svg>
            </div>

            <!-- Project Detail Popup HTML -->
            <div id="projectPopup-<?php echo esc_attr($unique_id); ?>" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center hidden portfolio-popup">
                <div class="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl">
                    <!-- Popup content will be loaded here via AJAX -->
                    <div class="popup-content">
                        <div class="flex justify-center items-center p-12">
                            <div class="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2" style="border-color: <?php echo esc_attr($secondary_color); ?>;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <style>
            .fade-in {
                animation: fadeIn 0.3s ease-in-out;
            }

            @keyframes fadeIn {
                from {
                    opacity: 0;
                }

                to {
                    opacity: 1;
                }
            }

            .portfolio-popup {
                transition: opacity 0.3s ease;
            }

            .floating {
                animation: floating 3s ease-in-out infinite;
            }

            .floating-delay-2 {
                animation-delay: 1.5s;
            }

            @keyframes floating {
                0% {
                    transform: translateY(0);
                }

                50% {
                    transform: translateY(-10px);
                }

                100% {
                    transform: translateY(0);
                }
            }

            .badge-pulse {
                animation: badgePulse 2s ease-in-out infinite;
            }

            @keyframes badgePulse {
                0% {
                    opacity: 0;
                }

                50% {
                    opacity: 0.1;
                }

                100% {
                    opacity: 0;
                }
            }

            .hover-up {
                transition: transform 0.3s ease;
            }

            .hover-up:hover {
                transform: translateY(-10px);
            }

            .pulse-ring {
                position: relative;
            }

            .pulse-ring:before {
                content: '';
                position: absolute;
                top: -4px;
                left: -4px;
                right: -4px;
                bottom: -4px;
                border-radius: 50%;
                border: 2px solid rgba(236, 72, 153, 0.3);
                animation: pulse 2s linear infinite;
            }

            @keyframes pulse {
                0% {
                    transform: scale(0.5);
                    opacity: 0;
                }

                50% {
                    opacity: 0.5;
                }

                100% {
                    transform: scale(1.2);
                    opacity: 0;
                }
            }
        </style>

        <script>

        </script>
<?php
    }
}




// Add AJAX variables to frontend
function azia_enqueue_scripts()
{
    wp_localize_script('jquery', 'azia_ajax_object', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('azia_ajax_nonce'),
    ]);
}
add_action('wp_enqueue_scripts', 'azia_enqueue_scripts');
