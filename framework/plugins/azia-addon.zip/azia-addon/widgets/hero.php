<?php

/**
 * Social Media Hero Widget
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Social Media Hero Widget
 *
 * Custom Elementor widget for a social media hero section
 */
class Elementor_Hero_Widget extends \Elementor\Widget_Base
{

    /**
     * Get widget name.
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'social_media_hero';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return esc_html__('Social Media Hero', 'azia-addon');
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-banner';
    }

    /**
     * Get widget categories.
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['azia'];
    }

    /**
     * Get widget keywords.
     *
     * @return array Widget keywords.
     */
    public function get_keywords()
    {
        return ['hero', 'social media', 'profile', 'header'];
    }

    /**
     * Register widget controls.
     */
    protected function register_controls()
    {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // Badge Text
        $this->add_control(
            'badge_text',
            [
                'label' => esc_html__('Badge Text', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Social Media Strategist & Content Creator', 'azia-addon'),
            ]
        );

        // Heading
        $this->add_control(
            'heading_text',
            [
                'label' => esc_html__('Heading', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Crafting <span class="gradient-text">digital stories</span> that captivate & convert', 'azia-addon'),
            ]
        );

        // Subheading
        $this->add_control(
            'subheading_text',
            [
                'label' => esc_html__('Subheading', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('I help brands build authentic connections with their audience through strategic content and data-driven social media management that <span class="text-sky-600 font-medium">drives real results</span>.', 'azia-addon'),
            ]
        );

        // Button 1 Text
        $this->add_control(
            'button1_text',
            [
                'label' => esc_html__('Button 1 Text', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('View My Work', 'azia-addon'),
            ]
        );

        // Button 1 Link
        $this->add_control(
            'button1_link',
            [
                'label' => esc_html__('Button 1 Link', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => esc_html__('https://your-link.com', 'azia-addon'),
                'default' => [
                    'url' => '#portfolio',
                ],
            ]
        );

        // Button 2 Text
        $this->add_control(
            'button2_text',
            [
                'label' => esc_html__('Button 2 Text', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Let\'s Connect', 'azia-addon'),
            ]
        );

        // Button 2 Link
        $this->add_control(
            'button2_link',
            [
                'label' => esc_html__('Button 2 Link', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => esc_html__('https://your-link.com', 'azia-addon'),
                'default' => [
                    'url' => '#contact',
                ],
            ]
        );

        $this->end_controls_section();

        // Stats Section
        $this->start_controls_section(
            'stats_section',
            [
                'label' => esc_html__('Stats', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_stats',
            [
                'label' => esc_html__('Show Stats Section', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'azia-addon'),
                'label_off' => esc_html__('No', 'azia-addon'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'stat_value',
            [
                'label' => esc_html__('Stat Value', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '5+',
            ]
        );

        $repeater->add_control(
            'stat_unit',
            [
                'label' => esc_html__('Stat Unit', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'yrs',
            ]
        );

        $repeater->add_control(
            'stat_label',
            [
                'label' => esc_html__('Stat Label', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Experience',
            ]
        );



        $this->add_control(
            'stats_list',
            [
                'label' => esc_html__('Stats', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'stat_value' => '5+',
                        'stat_unit' => 'yrs',
                        'stat_label' => 'Experience',

                    ],
                    [
                        'stat_value' => '50+',
                        'stat_unit' => 'brands',
                        'stat_label' => 'Happy Clients',

                    ],
                    [
                        'stat_value' => '300',
                        'stat_unit' => '%',
                        'stat_label' => 'Average Growth',

                    ],
                ],
                'title_field' => '{{{ stat_value }}} {{{ stat_unit }}} - {{{ stat_label }}}',
                'condition' => [
                    'show_stats' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Profile Image
        $this->start_controls_section(
            'profile_section',
            [
                'label' => esc_html__('Profile Image', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // Profile Image
        $this->add_control(
            'profile_image',
            [
                'label' => esc_html__('Profile Image', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->end_controls_section();

        // Social Media Stats
        $this->start_controls_section(
            'social_media_section',
            [
                'label' => esc_html__('Social Media Stats', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );



        // Social Media Stats Repeater
        $this->add_control(
            'social_media_heading',
            [
                'label' => esc_html__('Social Media Stats', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'platform_name',
            [
                'label' => esc_html__('Platform Name', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Instagram',
            ]
        );

        $repeater->add_control(
            'platform_icon',
            [
                'label' => esc_html__('Platform Icon', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fab fa-instagram',
                    'library' => 'fa-brands',
                ],
            ]
        );

        $repeater->add_control(
            'followers_count',
            [
                'label' => esc_html__('Followers Count', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '45.2K',
            ]
        );

        $repeater->add_control(
            'followers_label',
            [
                'label' => esc_html__('Followers Label', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Followers',
            ]
        );

        $repeater->add_control(
            'progress_percentage',
            [
                'label' => esc_html__('Progress (%)', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 75,
                ],
            ]
        );

        $repeater->add_control(
            'card_position',
            [
                'label' => esc_html__('Card Position', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'top-right',
                'options' => [
                    'top-right' => esc_html__('Top Right', 'azia-addon'),
                    'top-left' => esc_html__('Top Left', 'azia-addon'),
                    'bottom-right' => esc_html__('Bottom Right', 'azia-addon'),
                    'bottom-left' => esc_html__('Bottom Left', 'azia-addon'),
                    'center-right' => esc_html__('Center Right', 'azia-addon'),
                    'center-left' => esc_html__('Center Left', 'azia-addon'),
                ],
            ]
        );

        $repeater->add_control(
            'start_color',
            [
                'label' => esc_html__('Progress Start Color', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'description' => esc_html__('Leave empty to use accent color', 'azia-addon'),
            ]
        );

        $repeater->add_control(
            'end_color',
            [
                'label' => esc_html__('Progress End Color', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'description' => esc_html__('Leave empty to use secondary color', 'azia-addon'),
            ]
        );

        $this->add_control(
            'social_platforms',
            [
                'label' => esc_html__('Social Platforms', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'platform_name' => 'Instagram',
                        'platform_icon' => [
                            'value' => 'fab fa-instagram',
                            'library' => 'fa-brands',
                        ],
                        'followers_count' => '45.2K',
                        'followers_label' => 'Followers',
                        'progress_percentage' => [
                            'size' => 75,
                        ],
                        'card_position' => 'top-right',
                        'start_color' => '#fb64b6',
                        'end_color' => '#ad46ff',
                    ],
                    [
                        'platform_name' => 'TikTok',
                        'platform_icon' => [
                            'value' => 'fab fa-tiktok',
                            'library' => 'fa-brands',
                        ],
                        'followers_count' => '102K',
                        'followers_label' => 'Followers',
                        'progress_percentage' => [
                            'size' => 92,
                        ],
                        'card_position' => 'center-left',
                        'start_color' => '#000000',
                        'end_color' => '#364153',
                    ],
                    [
                        'platform_name' => 'YouTube',
                        'platform_icon' => [
                            'value' => 'fab fa-youtube',
                            'library' => 'fa-brands',
                        ],
                        'followers_count' => '28.6K',
                        'followers_label' => 'Subscribers',
                        'progress_percentage' => [
                            'size' => 67,
                        ],
                        'card_position' => 'bottom-right',
                        'start_color' => '#fb2c36',
                        'end_color' => '#e7000b',

                    ],
                ],
                'title_field' => '{{{ platform_name }}}',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'verified_badge_section',
            [
                'label' => esc_html__('Verified Badge', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_verified_badge',
            [
                'label' => esc_html__('Show Verified Badge', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'azia-addon'),
                'label_off' => esc_html__('No', 'azia-addon'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'verified_badge_icon',
            [
                'label' => esc_html__('Badge Icon', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-check',
                    'library' => 'fa-solid',
                ],
                'condition' => [
                    'show_verified_badge' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'verified_badge_label',
            [
                'label' => esc_html__('Badge Label', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Verified', 'azia-addon'),
                'condition' => [
                    'show_verified_badge' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'verified_badge_description',
            [
                'label' => esc_html__('Badge Description', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Content Creator', 'azia-addon'),
                'condition' => [
                    'show_verified_badge' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'verified_badge_position',
            [
                'label' => esc_html__('Badge Position', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'bottom-right',
                'options' => [
                    'top-right' => esc_html__('Top Right', 'azia-addon'),
                    'top-left' => esc_html__('Top Left', 'azia-addon'),
                    'bottom-right' => esc_html__('Bottom Right', 'azia-addon'),
                    'bottom-left' => esc_html__('Bottom Left', 'azia-addon'),
                    'bottom-center' => esc_html__('Bottom Center', 'azia-addon'),
                ],
                'condition' => [
                    'show_verified_badge' => 'yes',
                ],
            ]
        );
        $this->end_controls_section();

        // Style Tab - Colors
        $this->start_controls_section(
            'style_colors_section',
            [
                'label' => esc_html__('Colors', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        // Primary Color
        $this->add_control(
            'primary_color',
            [
                'label' => esc_html__('Primary Color', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#0ea5e9',
                'selectors' => [],
                'global' => [
                    'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_PRIMARY
                ]
            ]
        );

        // Secondary Color
        $this->add_control(
            'secondary_color',
            [
                'label' => esc_html__('Secondary Color', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#6366f1',
                'selectors' => [],
                'global' => [
                    'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_SECONDARY
                ]
            ]
        );

        // Accent_color Color
        $this->add_control(
            'accent_color_color',
            [
                'label' => esc_html__('Accent_color Color', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#f6339a',
                'selectors' => [],
                'global' => [
                    'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_ACCENT
                ]
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render widget output on the frontend.
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        // Colors
        $primary_color = !empty($settings['primary_color']) ? $settings['primary_color'] : '#0ea5e9'; //sky
        $secondary_color = !empty($settings['secondary_color']) ? $settings['secondary_color'] : '#6366f1'; //indigo
        $accent_color = !empty($settings['accent_color_color']) ? $settings['accent_color_color'] : '#f6339a'; //pink

        // Get the URLs with proper format
        $button1_url = !empty($settings['button1_link']['url']) ? $settings['button1_link']['url'] : '#portfolio';
        $button2_url = !empty($settings['button2_link']['url']) ? $settings['button2_link']['url'] : '#contact';

        // Get the target attribute for links
        $button1_target = !empty($settings['button1_link']['is_external']) ? ' target="_blank"' : '';
        $button2_target = !empty($settings['button2_link']['is_external']) ? ' target="_blank"' : '';

        // Get image URL
        $profile_image_url = !empty($settings['profile_image']['url']) ? $settings['profile_image']['url'] : \Elementor\Utils::get_placeholder_image_src();

?>

        <!-- Hero Section Start -->
        <section class="hero-section pt-24 pb-20 md:py-24 relative" style="--primary-color: <?php echo esc_attr($primary_color); ?>;--secondary-color: <?php echo esc_attr($secondary_color); ?>;--accent-color: <?php echo esc_attr($accent_color); ?>; ">
            <!-- Decorative elements -->
            <div class="absolute top-20 right-10 w-32 h-32 rounded-full blur-3xl opacity-30" style="background: linear-gradient(to right, <?php echo esc_attr(adjust_color_brightness($primary_color, 200, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 200, 1)); ?>);"></div>
            <div class="absolute bottom-10 left-10 w-40 h-40 rounded-full blur-3xl opacity-30" style="background: linear-gradient(to right, <?php echo esc_attr(adjust_color_brightness($secondary_color, 200, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($accent_color, 200, 1)); ?>);"></div>

            <!-- Floating abstract shapes -->
            <div class="absolute left-10 top-24 w-6 h-6 rounded-full opacity-20 floating" style="background-color: <?php echo esc_attr(adjust_color_brightness($primary_color, 500, 1)); ?>"></div>
            <div class="absolute right-96 bottom-24 w-3 h-3 rounded-full opacity-30 floating floating-delay-1" style="background-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 500, 1)); ?>"></div>
            <div class="absolute left-1/3 top-1/4 w-4 h-4 rounded-sm opacity-20 floating floating-delay-2" style="background-color: <?php echo esc_attr(adjust_color_brightness($accent_color, 500, 1)); ?>"></div>
            <div class="absolute right-1/4 top-36 w-8 h-8 border-2 rounded-lg opacity-20 floating floating-delay-3" style="border-color: <?php echo esc_attr(adjust_color_brightness($primary_color, 300, 1)); ?>"></div>

            <!-- Main content -->
            <div class="container mx-auto px-6">
                <div class="flex flex-col lg:flex-row items-center justify-between gap-12 md:gap-24 lg:gap-12">
                    <!-- Left content -->
                    <div class="w-full lg:w-1/2 fade-in-up">
                        <!-- Badge with improved animation -->
                        <div class="inline-block px-4 py-1.5 backdrop-blur-md rounded-full text-sm font-semibold mb-8 shadow-sm badge-text" style="background: linear-gradient(to right, <?php echo esc_attr(adjust_color_brightness($primary_color, 100, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 100, 1)); ?>); color: <?php echo esc_attr($primary_color); ?>">
                            <span class="flex items-center">
                                <span class="w-2 h-2 rounded-full mr-2 animate-pulse" style="background-color: <?php echo esc_attr($primary_color); ?>"></span>
                                <span style="animation-delay: 0.1s"><?php echo esc_html($settings['badge_text']); ?></span>
                            </span>
                        </div>

                        <!-- Headline -->
                        <h1 class="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-8 leading-tight fade-in-up delay-100 tracking-tight">
                            <?php echo wp_kses_post($settings['heading_text']); ?>
                        </h1>

                        <!-- Subheadline -->
                        <p class="text-lg md:text-xl text-gray-600 mb-10 max-w-lg fade-in-up delay-200 leading-relaxed">
                            <?php echo wp_kses_post($settings['subheading_text']); ?>
                        </p>

                        <!-- CTA Buttons -->
                        <div class="flex flex-wrap gap-5 fade-in-up delay-300">
                            <a href="<?php echo esc_url($button1_url); ?>" <?php echo $button1_target; ?> class="px-7 py-3.5 text-white font-medium rounded-full transition-all flex items-center magnetic-btn glow" style="background: linear-gradient(to right, <?php echo esc_attr($primary_color); ?>, <?php echo esc_attr($secondary_color); ?>);">
                                <span><?php echo esc_html($settings['button1_text']); ?></span>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ml-2 transition-transform duration-300 group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                </svg>
                            </a>
                            <a href="<?php echo esc_url($button2_url); ?>" <?php echo $button2_target; ?> class="px-7 py-3.5 bg-white border border-gray-200 font-medium rounded-full transition-all magnetic-btn shadow-sm hover:shadow-md" style="hover:border-color: <?php echo esc_attr(adjust_color_brightness($primary_color, 300, 1)); ?>; hover:color: <?php echo esc_attr($primary_color); ?>">
                                <span><?php echo esc_html($settings['button2_text']); ?></span>
                            </a>
                        </div>

                        <!-- Stats with improved visualization -->
                        <?php if (!empty($settings['show_stats']) && $settings['show_stats'] === 'yes' && !empty($settings['stats_list'])) : ?>
                            <!-- Stats with improved visualization -->
                            <div class="flex flex-wrap gap-8 mt-12 fade-in-up delay-400">
                                <?php foreach ($settings['stats_list'] as $index => $stat) :
                                ?>
                                    <div class="relative">
                                        <div class="text-4xl font-bold text-gray-800 flex items-end">
                                            <?php echo esc_html($stat['stat_value']); ?>
                                            <span class="text-2xl ml-1" style="color: <?php echo esc_attr($primary_color); ?>"><?php echo esc_html($stat['stat_unit']); ?></span>
                                        </div>
                                        <div class="text-sm text-gray-500 mt-1"><?php echo esc_html($stat['stat_label']); ?></div>
                                        <div class="absolute -top-1 -right-1 w-8 h-8 rounded-full -z-10" style="background-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>"></div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Right content - Profile & social proof with mobile optimizations -->
                    <div class="w-full md:w-4/5 lg:w-1/2 flex flex-col lg:flex-row justify-center lg:justify-end fade-in-up delay-200 md:pr-12">
                        <div class="relative">
                            <!-- Background blur effects -->
                            <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 rounded-full blur-2xl -z-10" style="background: linear-gradient(to bottom right, <?php echo esc_attr(adjust_color_brightness($primary_color, 200, 0.4)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 200, 0.4)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 200, 0.4)); ?>);"></div>

                            <!-- Profile Image with increased size -->
                            <div class="relative w-full h-96 md:w-full md:h-[600px] lg:w-[400px] lg:h-[400px] 2xl:w-[500px] 2xl:h-[500px] rounded-3xl overflow-hidden modern-card tilt-card hover-up floating floating-delay-1 mx-auto md:mx-0">
                                <!-- Border style -->
                                <div class="absolute inset-0 p-1 rounded-3xl" style="background: linear-gradient(to bottom right, <?php echo esc_attr(adjust_color_brightness($primary_color, 200, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 200, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($accent_color, 200, 1)); ?>);"></div>

                                <!-- Image container with original tilt-card-inner -->
                                <div class="absolute inset-1 rounded-[22px] overflow-hidden bg-white tilt-card-inner">
                                    <!-- Profile Image -->
                                    <img src="<?php echo esc_url($profile_image_url); ?>"
                                        alt="Profile Image" class="w-full !h-full object-cover hover:scale-105 transition-transform duration-700" />
                                </div>
                            </div>

                            <!-- Mobile social cards container - only visible on small screens -->
                            <div class="md:hidden mt-8 flex flex-col gap-3 max-w-md mx-auto">
                                <?php foreach ($settings['social_platforms'] as $index => $platform) :
                                    // Get progress percentage
                                    $progress = isset($platform['progress_percentage']['size']) ? $platform['progress_percentage']['size'] : 75;

                                    // Get colors
                                    $start_color = !empty($platform['start_color']) ? $platform['start_color'] : $accent_color;
                                    $end_color = !empty($platform['end_color']) ? $platform['end_color'] : $secondary_color;
                                ?>
                                    <div class="p-3 bg-white rounded-xl shadow-sm w-full">
                                        <div class="flex items-center">
                                            <i class="<?php echo esc_attr($platform['platform_icon']['value']); ?> text-xl mr-2 neon-glow" style="color: <?php echo esc_attr($start_color); ?>"></i>
                                            <div>
                                                <div class="text-xs text-gray-500"><?php echo esc_html($platform['platform_name']); ?></div>
                                                <div class="flex items-baseline">
                                                    <span class="text-sm font-semibold"><?php echo esc_html($platform['followers_count']); ?></span>
                                                    <span class="text-xs ml-1 text-gray-500"><?php echo esc_html($platform['followers_label']); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mt-2 w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                                            <div class="h-full rounded-full progress-bar" style="width: <?php echo esc_attr($progress); ?>%; background: linear-gradient(to right, <?php echo esc_attr($start_color); ?>, <?php echo esc_attr($end_color); ?>);"></div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>

                                <!-- Add verified badge to mobile stacked layout if enabled -->
                                <?php if (!empty($settings['show_verified_badge']) && $settings['show_verified_badge'] === 'yes') : ?>
                                    <div class="p-3 bg-white rounded-xl shadow-sm w-full">
                                        <div class="flex items-center">
                                            <div class="w-7 h-7 rounded-full flex items-center justify-center mr-2 animate-pulse" style="background: linear-gradient(to bottom right, <?php echo esc_attr(adjust_color_brightness($primary_color, 400, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 500, 1)); ?>);">
                                                <i class="<?php echo esc_attr($settings['verified_badge_icon']['value']); ?> text-white text-sm"></i>
                                            </div>
                                            <div>
                                                <div class="text-xs text-gray-500"><?php echo esc_html($settings['verified_badge_label']); ?></div>
                                                <div class="text-xs font-semibold"><?php echo esc_html($settings['verified_badge_description']); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Desktop social cards - only visible on md screens and up -->
                            <?php foreach ($settings['social_platforms'] as $index => $platform) :
                                // Get position classes based on setting
                                $position_class = '';

                                switch ($platform['card_position']) {
                                    case 'top-right':
                                        $position_class = 'absolute -top-5 -right-5';
                                        break;
                                    case 'top-left':
                                        $position_class = 'absolute -top-5 -left-16';
                                        break;
                                    case 'bottom-right':
                                        $position_class = 'absolute -bottom-5 right-12';
                                        break;
                                    case 'bottom-left':
                                        $position_class = 'absolute -bottom-5 -left-16';
                                        break;
                                    case 'center-right':
                                        $position_class = 'absolute top-1/3 -right-16';
                                        break;
                                    case 'center-left':
                                        $position_class = 'absolute top-1/3 -left-16';
                                        break;
                                }

                                // Animation delay class
                                $delay_class = ($index % 3 === 0) ? '' : 'floating-delay-' . ($index % 3);

                                // Get progress percentage
                                $progress = isset($platform['progress_percentage']['size']) ? $platform['progress_percentage']['size'] : 75;

                                // Get colors
                                $start_color = !empty($platform['start_color']) ? $platform['start_color'] : $accent_color;
                                $end_color = !empty($platform['end_color']) ? $platform['end_color'] : $secondary_color;
                            ?>
                                <div class="<?php echo esc_attr($position_class); ?> p-4 bg-white rounded-xl shadow-sm modern-card social-card transform transition-all <?php echo esc_attr($delay_class); ?> hidden md:block">
                                    <div class="flex items-center">
                                        <i class="<?php echo esc_attr($platform['platform_icon']['value']); ?> text-2xl mr-3 neon-glow" style="color: <?php echo esc_attr($start_color); ?>"></i>
                                        <div>
                                            <div class="text-xs text-gray-500"><?php echo esc_html($platform['platform_name']); ?></div>
                                            <div class="flex items-baseline">
                                                <span class="text-base font-semibold"><?php echo esc_html($platform['followers_count']); ?></span>
                                                <span class="text-xs ml-1 text-gray-500"><?php echo esc_html($platform['followers_label']); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-2 w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                                        <div class="h-full rounded-full progress-bar" style="width: <?php echo esc_attr($progress); ?>%; background: linear-gradient(to right, <?php echo esc_attr($start_color); ?>, <?php echo esc_attr($end_color); ?>);"></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>

                            <!-- Verified badge with animation - desktop only -->
                            <?php if (!empty($settings['show_verified_badge']) && $settings['show_verified_badge'] === 'yes') :
                                // Get position classes based on setting
                                $position_class = '';

                                switch ($settings['verified_badge_position']) {
                                    case 'top-right':
                                        $position_class = 'absolute top-1/4 -right-12';
                                        break;
                                    case 'top-left':
                                        $position_class = 'absolute top-1/4 -left-12';
                                        break;
                                    case 'bottom-right':
                                        $position_class = 'absolute bottom-1/4 -right-12';
                                        break;
                                    case 'bottom-left':
                                        $position_class = 'absolute bottom-1/4 -left-12';
                                        break;
                                    case 'bottom-center':
                                        $position_class = 'absolute -bottom-5 left-1/2 -translate-x-1/2';
                                        break;
                                    default:
                                        $position_class = 'absolute bottom-1/4 -right-12';
                                }
                            ?>
                                <div class="<?php echo esc_attr($position_class); ?> p-4 bg-white rounded-xl shadow-sm modern-card social-card transform transition-all floating-delay-3 hidden md:block">
                                    <div class="flex items-center">
                                        <div class="w-8 h-8 rounded-full flex items-center justify-center mr-3 animate-pulse" style="background: linear-gradient(to bottom right, <?php echo esc_attr(adjust_color_brightness($primary_color, 400, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 500, 1)); ?>);">
                                            <i class="<?php echo esc_attr($settings['verified_badge_icon']['value']); ?> text-white"></i>
                                        </div>
                                        <div>
                                            <div class="text-xs text-gray-500"><?php echo esc_html($settings['verified_badge_label']); ?></div>
                                            <div class="text-sm font-semibold"><?php echo esc_html($settings['verified_badge_description']); ?></div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- Additional decorative elements - hidden on mobile -->
                            <div class="absolute -top-2 -left-2 w-4 h-4 rounded-full opacity-60 hidden md:block" style="background-color: <?php echo esc_attr($secondary_color); ?>"></div>
                            <div class="absolute bottom-10 left-0 w-6 h-6 rounded-full opacity-60 floating floating-delay-2 hidden md:block" style="background: linear-gradient(to bottom right, <?php echo esc_attr(adjust_color_brightness($primary_color, 400, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 500, 1)); ?>);"></div>
                            <div class="absolute top-1/3 right-0 w-3 h-3 rounded-full opacity-60 floating floating-delay-3 hidden md:block" style="background-color: <?php echo esc_attr($accent_color); ?>"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Decorative wave divider -->
            <div class="absolute bottom-0 left-0 w-full">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 100" class="text-gray-50">
                    <path fill="currentColor" fill-opacity="1" d="M0,64L60,58.7C120,53,240,43,360,53.3C480,64,600,96,720,96C840,96,960,64,1080,58.7C1200,53,1320,75,1380,85.3L1440,96L1440,100L1380,100C1320,100,1200,100,1080,100C960,100,840,100,720,100C600,100,480,100,360,100C240,100,120,100,60,100L0,100Z"></path>
                </svg>
            </div>
        </section>
<?php
    }
}
