<?php
if (class_exists('\Elementor\Plugin') && class_exists('\Elementor\Core\Settings\Manager')) {
    try {
        $page_settings_manager = \Elementor\Core\Settings\Manager::get_settings_managers('page');
        if ($page_settings_manager) {
            $page_settings_model = $page_settings_manager->get_model(get_the_ID());
            if ($page_settings_model) {
                $stat_label = $page_settings_model->get_settings('stat_label');
                $stat_icon = $page_settings_model->get_settings('stat_icon');
                $stats_list = [];
                $page_settings = $page_settings_model->get_settings();
                for ($i = 1; $i <= 3; $i++) {
                    if (!empty($page_settings["stat_label_{$i}"])) {
                        $stats_list[] = [
                            'stat_icon'   => $page_settings["stat_icon_{$i}"] ?? null,
                            'stat_label'  => $page_settings["stat_label_{$i}"] ?? '',
                        ];
                    }
                }
            }
        }
    } catch (Exception $e) {
        // Silently handle any errors that might occur when accessing Elementor
        error_log('Elementor settings access error: ' . $e->getMessage());
    }
}
?>
<div class="modern-card rounded-3xl overflow-hidden hover-up group portfolio-item flex flex-col <?php echo esc_attr($full_width_class); ?> <?php echo esc_attr(implode(' ', $cat_classes)); ?>" data-project-id="<?php echo esc_attr(get_the_ID()); ?>">
    <!-- Image Container with gradient overlay -->
    <div class="h-80 relative overflow-hidden">
        <?php if (has_post_thumbnail()) : ?>
            <?php the_post_thumbnail('large', ['class' => 'w-full !h-full object-cover transition-transform duration-700 group-hover:scale-110']); ?>
        <?php else : ?>
            <img src="<?php echo \Elementor\Utils::get_placeholder_image_src(); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" class="w-full !h-full object-cover transition-transform duration-700 group-hover:scale-110">
        <?php endif; ?>

        <!-- Gradient Overlay -->
        <div class="absolute inset-0 opacity-70 transition-opacity group-hover:opacity-90" style="background: linear-gradient(to top, <?php echo esc_attr(adjust_color_brightness($secondary_color, 900, 0.8)); ?>, transparent);"></div>

        <!-- Category Pill -->
        <?php if (!empty($category_name)) : ?>
            <div class="category-pill absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-medium bg-white/20 backdrop-blur-md text-white">
                <?php echo esc_html($category_name); ?>
            </div>
        <?php endif; ?>

        <!-- Stats -->
        <div class="absolute bottom-6 left-6 right-6 flex flex-wrap gap-4">
            <div class="flex flex-wrap gap-8 pt-6">
                <?php
                foreach ($stats_list as $stat): ?>
                    <div class="px-3 py-1.5 rounded-full text-xs font-medium bg-white/20 backdrop-blur-md text-white flex items-center">
                        <?php
                        if (!empty($stat['stat_icon']) && class_exists('\Elementor\Icons_Manager')) {
                        ?>
                            <i class="<?php echo esc_attr($stat['stat_icon']['value']); ?> mr-1.5"></i>
                        <?php
                        }
                        ?>
                        <span><?php echo esc_html($stat['stat_label']); ?></span>
                    </div>
                <?php
                endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Content -->
    <div class="p-6 flex-1 flex flex-col justify-between">
        <h3 class="text-xl font-bold text-gray-800 mb-2"><?php the_title(); ?></h3>
        <p class="text-gray-600 mb-5">
            <?php echo wp_trim_words(get_the_excerpt(), 15, '...'); ?>
        </p>
        <div class="flex items-center justify-between">
            <button class="view-project-btn font-medium flex items-center text-sm transition-colors group" style="color: var(--secondary-color); hover:color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 600, 1)); ?>;" data-project-id="<?php echo esc_attr(get_the_ID()); ?>">
                <?php echo esc_html__('View Project', 'azia-addon'); ?>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 ml-1 transition-transform duration-300 group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
            </button>
        </div>
    </div>
</div>