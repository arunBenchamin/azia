<div class="flex flex-wrap items-center gap-2">
    <?php
    //$current_page = $page;
    if (!isset($current_page) || empty($current_page)) {
        $current_page = 1;
    }
    $total_pages = $query->max_num_pages;
 
    // Previous page link
     if ($current_page > 1) : ?>
        <a href="#" class="pagination-link px-4 py-2 border border-gray-200 rounded-md transition-colors" style="color: var(--secondary-color); hover:background-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>;" data-page="<?php echo esc_attr($current_page - 1); ?>">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
        </a>
    <?php else : ?>
        <span class="px-4 py-2 border border-gray-200 rounded-md text-gray-400 bg-gray-50 cursor-not-allowed">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
        </span>
    <?php endif; ?>
    
    <?php
    // Page numbers
    $range = 2; // Number of pages to show on each side of current page
    
    // Calculate start and end pages
    $start_page = max(1, $current_page - $range);
    $end_page = min($total_pages, $current_page + $range);
    
    // Always show first page
    if ($start_page > 1) : ?>
        <a href="<?php echo esc_url(add_query_arg('portfolio-page', 1)); ?>" class="px-4 py-2 border border-gray-200 rounded-md transition-colors" style="color: var(--secondary-color); hover:background-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>;">
            1
        </a>
        <?php if ($start_page > 2) : ?>
            <span class="px-2 text-gray-500">...</span>
        <?php endif;
    endif;
    
    // Page links
     for ($i = $start_page; $i <= $end_page; $i++) : 
        if ($i == $current_page) : ?>
            <span class="px-4 py-2 border rounded-md font-medium" style="border-color: var(--secondary-color); background-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>; color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 700, 1)); ?>;">
                <?php echo esc_html($i); ?>
            </span>
        <?php else : ?>
            <a href="#" class="pagination-link px-4 py-2 border border-gray-200 rounded-md transition-colors" style="color: var(--secondary-color); hover:background-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>;" data-page="<?php echo esc_attr($i); ?>">
                <?php echo esc_html($i); ?>
            </a>
        <?php endif;
    endfor;  
    
    // Always show last page
    if ($end_page < $total_pages) :
        if ($end_page < $total_pages - 1) : ?>
            <span class="px-2 text-gray-500">...</span>
        <?php endif; ?>
        <a href="<?php echo esc_url(add_query_arg('portfolio-page', $total_pages)); ?>" class="px-4 py-2 border border-gray-200 rounded-md transition-colors" style="color: var(--secondary-color); hover:background-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>;">
            <?php echo esc_html($total_pages); ?>
        </a>
    <?php endif;
    
    // Next page link
    if ($current_page < $total_pages) : ?>
        <a href="<?php echo esc_url(add_query_arg('portfolio-page', $current_page + 1)); ?>" class="px-4 py-2 border border-gray-200 rounded-md transition-colors" style="color: var(--secondary-color); hover:background-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>;">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
            </svg>
        </a>
    <?php else : ?>
        <span class="px-4 py-2 border border-gray-200 rounded-md text-gray-400 bg-gray-50 cursor-not-allowed">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
            </svg>
        </span>
    <?php endif; ?>
</div>