<?php

/**
 * Testimonial Carousel Widget
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Testimonial Carousel Widget
 *
 * Custom Elementor widget for displaying testimonials in an interactive carousel
 */
class Elementor_Testimonial_Carousel_Widget extends \Elementor\Widget_Base
{

    /**
     * Get widget name.
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'testimonial_carousel';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Testimonial Carousel', 'azia-addon');
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-testimonial-carousel';
    }

    /**
     * Get widget categories.
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['azia'];
    }

    /**
     * Get widget keywords.
     *
     * @return array Widget keywords.
     */
    public function get_keywords()
    {
        return ['testimonial', 'carousel', 'slider', 'review', 'feedback'];
    }

    /**
     * Register widget controls.
     */
    protected function register_controls()
    {
        // Carousel Settings
        $this->start_controls_section(
            'section_carousel_settings',
            [
                'label' => __('Carousel Settings', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __('Autoplay', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'azia-addon'),
                'label_off' => __('No', 'azia-addon'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay_speed',
            [
                'label' => __('Autoplay Speed', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 5000,
                'min' => 1000,
                'max' => 10000,
                'step' => 500,
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'pause_on_hover',
            [
                'label' => __('Pause on Hover', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'azia-addon'),
                'label_off' => __('No', 'azia-addon'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_arrows',
            [
                'label' => __('Show Arrows', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'azia-addon'),
                'label_off' => __('No', 'azia-addon'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_dots',
            [
                'label' => __('Show Dots', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'azia-addon'),
                'label_off' => __('No', 'azia-addon'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // Testimonials
        $this->start_controls_section(
            'section_testimonials',
            [
                'label' => __('Testimonials', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'rating',
            [
                'label' => __('Rating', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '5',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                ],
            ]
        );

        $repeater->add_control(
            'testimonial_content',
            [
                'label' => __('Testimonial Content', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Working with Azia has been nothing short of transformative for our brand. She doesn\'t just create beautiful content—she develops comprehensive strategies that deliver real results. Within 3 months, our engagement increased by 215% and our following grew by 10K+ genuine fans.', 'azia-addon'),
                'rows' => 6,
            ]
        );

        $repeater->add_control(
            'testimonial_title',
            [
                'label' => __('Testimonial Title', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Azia transformed our social presence with stunning visuals and data-driven strategy', 'azia-addon'),
            ]
        );

        $repeater->add_control(
            'client_name',
            [
                'label' => __('Client Name', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Sarah Johnson', 'azia-addon'),
            ]
        );

        $repeater->add_control(
            'client_position',
            [
                'label' => __('Client Position', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Marketing Director, Lumina Beauty', 'azia-addon'),
            ]
        );

        $repeater->add_control(
            'client_image',
            [
                'label' => __('Client Image', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'result_image',
            [
                'label' => __('Results Image', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // Changed from TEXT to a group of controls for the ROI section
        $repeater->add_control(
            'roi_heading',
            [
                'label' => __('ROI Section', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $repeater->add_control(
            'roi_label',
            [
                'label' => __('ROI Label', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('ROI Increase', 'azia-addon'),
            ]
        );

        $repeater->add_control(
            'roi_increase',
            [
                'label' => __('ROI Value', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('320%', 'azia-addon'),
            ]
        );

        $repeater->add_control(
            'roi_icon',
            [
                'label' => __('ROI Icon', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-arrow-trend-up',
                    'library' => 'fa-solid',
                ],
                'recommended' => [
                    'fa-solid' => [
                        'arrow-trend-up',
                        'arrow-up',
                        'chart-line',
                        'chart-simple',
                        'chart-column',
                        'arrow-up-right-dots',
                        'arrow-up-right',
                        'arrow-up-from-bracket',
                        'chart-pie',
                    ],
                ],
            ]
        );

        // Platform section
        $repeater->add_control(
            'platform_heading',
            [
                'label' => __('Platform Section', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        // Changed from SELECT to ICONS for platform icon
        $repeater->add_control(
            'platform_icon',
            [
                'label' => __('Platform Icon', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fab fa-instagram',
                    'library' => 'fa-brands',
                ],
                'recommended' => [
                    'fa-brands' => [
                        'instagram',
                        'tiktok',
                        'youtube',
                        'facebook',
                        'twitter',
                        'linkedin',
                    ],
                    'fa-solid' => [
                        'shopping-cart',
                        'store',
                        'bag-shopping',
                        'cart-shopping',
                    ],
                ],
            ]
        );

        $repeater->add_control(
            'platform_result',
            [
                'label' => __('Platform Result', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('24K new followers', 'azia-addon'),
            ]
        );

        $this->add_control(
            'testimonials',
            [
                'label' => __('Testimonials', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rating' => '5',
                        'testimonial_title' => __('Azia transformed our social presence with stunning visuals and data-driven strategy', 'azia-addon'),
                        'testimonial_content' => __('Working with Azia has been nothing short of transformative for our brand. She doesn\'t just create beautiful content—she develops comprehensive strategies that deliver real results. Within 3 months, our engagement increased by 215% and our following grew by 10K+ genuine fans.', 'azia-addon'),
                        'client_name' => __('Sarah Johnson', 'azia-addon'),
                        'client_position' => __('Marketing Director, Lumina Beauty', 'azia-addon'),
                        'roi_label' => __('ROI Increase', 'azia-addon'),
                        'roi_increase' => __('320%', 'azia-addon'),
                        'roi_icon' => [
                            'value' => 'fas fa-arrow-trend-up',
                            'library' => 'fa-solid',
                        ],
                        'platform_icon' => [
                            'value' => 'fab fa-instagram',
                            'library' => 'fa-brands',
                        ],
                        'platform_result' => __('24K new followers', 'azia-addon'),
                    ],
                    [
                        'rating' => '5',
                        'testimonial_title' => __('Our TikTok following exploded thanks to these innovative content strategies', 'azia-addon'),
                        'testimonial_content' => __('After struggling to gain traction on TikTok for months, we partnered with Azia and saw immediate results. Her trend analysis and custom content creation approach helped us go viral within weeks. Our account grew from 5K to 100K followers in just 2 months!', 'azia-addon'),
                        'client_name' => __('Michael Chen', 'azia-addon'),
                        'client_position' => __('CEO, Spark Apparel', 'azia-addon'),
                        'roi_label' => __('ROI Increase', 'azia-addon'),
                        'roi_increase' => __('215%', 'azia-addon'),
                        'roi_icon' => [
                            'value' => 'fas fa-arrow-trend-up',
                            'library' => 'fa-solid',
                        ],
                        'platform_icon' => [
                            'value' => 'fab fa-tiktok',
                            'library' => 'fa-brands',
                        ],
                        'platform_result' => __('95K new followers', 'azia-addon'),
                    ],
                    [
                        'rating' => '5',
                        'testimonial_title' => __('A game-changer for our e-commerce social strategy across all platforms', 'azia-addon'),
                        'testimonial_content' => __('Azia\'s holistic approach to our social media transformed how we connect with our audience. Her content strategy aligned perfectly with our brand vision while delivering measurable results. We\'ve seen a 78% increase in social traffic conversion since implementing her recommendations.', 'azia-addon'),
                        'client_name' => __('Jessica Martinez', 'azia-addon'),
                        'client_position' => __('E-commerce Director, Urban Collective', 'azia-addon'),
                        'roi_label' => __('ROI Increase', 'azia-addon'),
                        'roi_increase' => __('178%', 'azia-addon'),
                        'roi_icon' => [
                            'value' => 'fas fa-chart-line',
                            'library' => 'fa-solid',
                        ],
                        'platform_icon' => [
                            'value' => 'fas fa-shopping-cart',
                            'library' => 'fa-solid',
                        ],
                        'platform_result' => __('45K new followers', 'azia-addon'),
                    ],
                ],
                'title_field' => '{{{ client_name }}} - {{{ testimonial_title }}}',
            ]
        );

        $this->end_controls_section();
        

        // Colors Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Colors', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

     // Primary Color
     $this->add_control(
        'primary_color',
        [
            'label' => esc_html__('Primary Color', 'azia-addon'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#0ea5e9',
            'selectors' => [],
            'global' => [
                'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_PRIMARY
            ]
        ]
    );

    // Secondary Color
    $this->add_control(
        'secondary_color',
        [
            'label' => esc_html__('Secondary Color', 'azia-addon'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#6366f1',
            'selectors' => [],
            'global' => [
                'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_SECONDARY
            ]
        ]
    );
 

        $this->end_controls_section(); 
       
    }

    /**
     * Render widget output on the frontend.
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $testimonials = $settings['testimonials'];

        // Get ID for the carousel
        $carousel_id = 'testimonial-carousel-' . $this->get_id();

        // Get color settings
        $primary_color = !empty($settings['primary_color']) ? $settings['primary_color'] : '#0ea5e9'; //sky
        $secondary_color = !empty($settings['secondary_color']) ? $settings['secondary_color'] : '#6366f1'; //indigo
        // $accent_color = !empty($settings['accent_color_color']) ? $settings['accent_color_color'] : '#f6339a'; //pink

        // Carousel settings
        $autoplay = $settings['autoplay'] === 'yes' ? 'true' : 'false';
        $autoplay_speed = !empty($settings['autoplay_speed']) ? $settings['autoplay_speed'] : 5000;
        $pause_on_hover = $settings['pause_on_hover'] === 'yes' ? 'true' : 'false';
        $show_arrows = $settings['show_arrows'] === 'yes';
        $show_dots = $settings['show_dots'] === 'yes';

?>
        <!-- Testimonial Carousel Widget -->
        <section class="testimonial-section pt-24 bg-gray-50 " style="--primary-color: <?php echo esc_attr($primary_color); ?>; --secondary-color: <?php echo esc_attr($secondary_color); ?>;" id="testimonial" >
            <div class="container" id="<?php echo esc_attr($carousel_id); ?>" >
                <div class="testimonial-carousel relative z-1">
                    <?php if ($show_arrows) : ?>
                        <!-- Navigation Arrows -->

                        <a class="testimonial-arrow prev absolute left-0 -translate-x-1/2 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-white/80 shadow-md flex items-center justify-center hover:bg-white transition-all focus:outline-none cursor-pointer"
                            style="color: <?php echo esc_attr($secondary_color); ?>; hover:color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 700, 1)); ?>;"
                            aria-label="Previous testimonial">
                            <i class="fas fa-chevron-left"></i>
                        </a>

                        <a class="testimonial-arrow next absolute right-0 translate-x-1/2 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-white/80 shadow-md flex items-center justify-center hover:bg-white transition-all focus:outline-none cursor-pointer"
                            style="color: <?php echo esc_attr($secondary_color); ?>; hover:color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 700, 1)); ?>;"
                            aria-label="Next testimonial">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    <?php endif; ?>

                    <!-- Background gradient -->
                    <div
                        class="absolute inset-0 w-full h-full rounded-3xl transform -skew-y-1 -z-10"
                        style="background-image: linear-gradient(to right, <?php echo esc_attr(adjust_color_brightness($primary_color, 50, 1)); ?>, <?php echo esc_attr(adjust_color_brightness($secondary_color, 50, 1)); ?>);">
                    </div>

                    <div class="py-16 px-8 md:px-16 relative">
                        <!-- Decorative elements -->
                        <div class="absolute -top-10 -left-10 w-20 h-20 rounded-full opacity-80"
                            style="background-color: <?php echo esc_attr(adjust_color_brightness($primary_color, 100, 1)); ?>;"></div>
                        <div class="absolute -bottom-10 -right-10 w-20 h-20 rounded-full opacity-80"
                            style="background-color: <?php echo esc_attr(adjust_color_brightness($secondary_color, 100, 1)); ?>;"></div>

                        <!-- Quote icon -->
                        <div class="absolute top-10 left-10 opacity-50"
                            style="color: <?php echo esc_attr(adjust_color_brightness($primary_color, 200, 1)); ?>;">
                            <svg width="60" height="60" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M14 16C14 13.7909 12.2091 12 10 12C7.79086 12 6 13.7909 6 16V18C6 20.2091 7.79086 22 10 22C12.2091 22 14 20.2091 14 18V16Z"
                                    fill="currentColor" />
                                <path d="M14 16C14 16.7707 14 22.508 14 24C14 27.5376 13.5376 30.5376 12 34" stroke="currentColor"
                                    stroke-width="4" stroke-linecap="round" />
                                <path
                                    d="M28 16C28 13.7909 26.2091 12 24 12C21.7909 12 20 13.7909 20 16V18C20 20.2091 21.7909 22 24 22C26.2091 22 28 20.2091 28 18V16Z"
                                    fill="currentColor" />
                                <path d="M28 16C28 16.7707 28 22.508 28 24C28 27.5376 27.5376 30.5376 26 34" stroke="currentColor"
                                    stroke-width="4" stroke-linecap="round" />
                            </svg>
                        </div>

                        <div class="flex flex-col md:flex-row gap-10 items-center">
                            <!-- Testimonial content -->
                            <div class="md:w-2/3">
                                <div class="testimonial-slides fade-in-effect">
                                    <?php foreach ($testimonials as $index => $testimonial) : ?>
                                        <!-- Testimonial <?php echo $index + 1; ?> -->
                                        <div class="testimonial-slide<?php echo $index === 0 ? ' active' : ''; ?>" data-slide="<?php echo $index; ?>">
                                            <!-- Stars -->
                                            <div class="flex mb-6">
                                                <?php for ($i = 0; $i < $testimonial['rating']; $i++) : ?>
                                                    <svg class="w-6 h-6 text-amber-400" fill="currentColor" viewBox="0 0 20 20"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118l-2.8-2.034c-.783-.57-.38-1.81.588-1.81h3.462a1 1 0 00.95-.69l1.07-3.292z">
                                                        </path>
                                                    </svg>
                                                <?php endfor; ?>
                                            </div>

                                            <h3 class="text-2xl md:text-3xl font-bold text-gray-800 mb-6">
                                                "<?php echo esc_html($testimonial['testimonial_title']); ?>"
                                            </h3>

                                            <p class="text-gray-600 text-lg mb-8">
                                                <?php echo esc_html($testimonial['testimonial_content']); ?>
                                            </p>

                                            <!-- Client Info -->
                                            <div class="flex items-center">
                                                <div class="w-12 h-12 rounded-full overflow-hidden mr-4 border-2"
                                                    style="border-color: <?php echo esc_attr(adjust_color_brightness($primary_color, 100, 1)); ?>;">
                                                    <img
                                                        src="<?php echo esc_url($testimonial['client_image']['url']); ?>"
                                                        alt="<?php echo esc_attr($testimonial['client_name']); ?>" class="w-full h-full object-cover" />
                                                </div>
                                                <div>
                                                    <div class="font-semibold text-gray-800"><?php echo esc_html($testimonial['client_name']); ?></div>
                                                    <div class="text-sm text-gray-500"><?php echo esc_html($testimonial['client_position']); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>

                                <?php if ($show_dots) : ?>
                                    <!-- Navigation Dots -->
                                    <div class="testimonial-dots flex items-center gap-2 mt-10 fade-in-effect">
                                        <?php foreach ($testimonials as $index => $testimonial) : ?>
                                            <a class="testimonial-dot<?php echo $index === 0 ? ' active' : ''; ?> <?php echo $index === 0 ? 'w-10' : 'w-2'; ?> h-2 rounded-full"
                                                <?php if ($index === 0) : ?>
                                                style="background-color: <?php echo esc_attr($secondary_color); ?>;"
                                                <?php else : ?>
                                                style="background-color: #e5e7eb;"
                                                <?php endif; ?>
                                                data-slide="<?php echo $index; ?>"
                                                aria-label="View testimonial <?php echo $index + 1; ?>"></a>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Testimonial Image Section -->
                            <div class="md:w-1/3 fade-in-effect effect-1">
                                <div class="testimonial-images">
                                    <?php foreach ($testimonials as $index => $testimonial) : ?>
                                        <!-- Image <?php echo $index + 1; ?> -->
                                        <div class="testimonial-image relative<?php echo $index === 0 ? ' active' : ''; ?>" data-slide="<?php echo $index; ?>">
                                            <!-- Main Image -->
                                            <div
                                                class="modern-card rounded-2xl overflow-hidden hover-up p-2"
                                                style="background-image: linear-gradient(to bottom right, <?php echo esc_attr(adjust_color_brightness($primary_color, 100, 1)); ?>, #ffffff, <?php echo esc_attr(adjust_color_brightness($secondary_color, 100, 1)); ?>);">
                                                <div class="rounded-xl overflow-hidden">
                                                    <img
                                                        src="<?php echo esc_url($testimonial['result_image']['url']); ?>"
                                                        alt="Project Results" class="w-full h-full object-cover" />
                                                </div>
                                            </div>

                                            <!-- Results Highlight Pill -->
                                            <div
                                                class="absolute -bottom-5 -left-5 modern-card bg-white py-3 px-5 rounded-full shadow-md flex items-center gap-3 hover-up">
                                                <div
                                                    class="w-10 h-10 rounded-full flex items-center justify-center text-white"
                                                    style="background-color: <?php echo esc_attr($secondary_color); ?>;">
                                                    <i class="<?php echo esc_attr($testimonial['roi_icon']['value']); ?>"></i>
                                                </div>
                                                <div>
                                                    <div class="text-xs text-gray-500"><?php echo esc_html($testimonial['roi_label']); ?></div>
                                                    <div class="font-bold text-gray-800">+<?php echo esc_html($testimonial['roi_increase']); ?></div>
                                                </div>
                                            </div>

                                            <!-- Platform Results Pill -->
                                            <div class="absolute -top-4 -right-4 modern-card bg-white py-2 px-4 rounded-full shadow-md hover-up">
                                                <div class="flex items-center gap-2">
                                                    <i class="<?php echo esc_attr($testimonial['platform_icon']['value']); ?>"
                                                         ></i>
                                                    <span class="text-gray-800 font-medium"><?php echo esc_html($testimonial['platform_result']); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    
        <!-- Carousel JavaScript -->
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const carousel = document.getElementById('<?php echo esc_attr($carousel_id); ?>');
                if (!carousel) return;

                const slides = carousel.querySelectorAll('.testimonial-slide');
                const images = carousel.querySelectorAll('.testimonial-image');
                const dots = carousel.querySelectorAll('.testimonial-dot');
                const prevBtn = carousel.querySelector('.testimonial-arrow.prev');
                const nextBtn = carousel.querySelector('.testimonial-arrow.next');

                let currentSlide = 0;
                const slideCount = slides.length;

                // Timer for autoplay
                let slideTimer;

                // Set autoplay if enabled
                if (<?php echo $autoplay; ?>) {
                    startAutoplay();
                }

                // Previous button click
                if (prevBtn) {
                    prevBtn.addEventListener('click', () => {
                        changeSlide(currentSlide - 1);
                        if (<?php echo $autoplay; ?> && <?php echo $pause_on_hover; ?>) {
                            resetAutoplay();
                        }
                    });
                }

                // Next button click
                if (nextBtn) {
                    nextBtn.addEventListener('click', () => {
                        changeSlide(currentSlide + 1);
                        if (<?php echo $autoplay; ?> && <?php echo $pause_on_hover; ?>) {
                            resetAutoplay();
                        }
                    });
                }

                // Dot navigation
                dots.forEach((dot, index) => {
                    dot.addEventListener('click', () => {
                        changeSlide(index);
                        if (<?php echo $autoplay; ?> && <?php echo $pause_on_hover; ?>) {
                            resetAutoplay();
                        }
                    });
                });

                // Pause on hover
                if (<?php echo $autoplay; ?> && <?php echo $pause_on_hover; ?>) {
                    carousel.addEventListener('mouseenter', () => {
                        clearInterval(slideTimer);
                    });

                    carousel.addEventListener('mouseleave', () => {
                        startAutoplay();
                    });
                }

                // Change slide function
                function changeSlide(index) {
                    // Handle circular navigation
                    if (index < 0) {
                        index = slideCount - 1;
                    } else if (index >= slideCount) {
                        index = 0;
                    }

                    // Deactivate current slide
                    slides[currentSlide].classList.remove('active');
                    images[currentSlide].classList.remove('active');

                    if (dots.length > 0) {
                        dots[currentSlide].classList.remove('active');
                        dots[currentSlide].classList.remove('w-10');
                        dots[currentSlide].classList.add('w-2');
                        dots[currentSlide].classList.remove('bg-indigo-500');
                        dots[currentSlide].classList.add('bg-gray-200');
                    }

                    // Activate new slide
                    currentSlide = index;
                    slides[currentSlide].classList.add('active');
                    images[currentSlide].classList.add('active');

                    if (dots.length > 0) {
                        dots[currentSlide].classList.add('active');
                        dots[currentSlide].classList.remove('w-2');
                        dots[currentSlide].classList.add('w-10');
                        dots[currentSlide].classList.remove('bg-gray-200');
                        dots[currentSlide].classList.add('bg-indigo-500');
                    }
                }

                // Autoplay function
                function startAutoplay() {
                    // Clear any existing timer
                    if (slideTimer) {
                        clearInterval(slideTimer);
                    }

                    // Start new timer
                    slideTimer = setInterval(() => {
                        changeSlide(currentSlide + 1);
                    }, <?php echo $autoplay_speed; ?>);
                }

                // Reset autoplay timer
                function resetAutoplay() {
                    clearInterval(slideTimer);
                    startAutoplay();
                }
            });
        </script>
<?php
    }
}
