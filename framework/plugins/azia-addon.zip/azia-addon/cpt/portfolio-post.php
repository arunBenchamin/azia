<?php
/**
 * Register Portfolio Custom Post Type
 */
function create_portfolio_post_type() {
    $labels = array(
        'name'               => 'Portfolio Projects',
        'singular_name'      => 'Portfolio Project',
        'menu_name'          => 'Portfolio',
        'add_new'            => 'Add New Project',
        'add_new_item'       => 'Add New Portfolio Project',
        'edit_item'          => 'Edit Portfolio Project',
        'new_item'           => 'New Portfolio Project',
        'view_item'          => 'View Portfolio Project',
        'search_items'       => 'Search Portfolio Projects',
        'not_found'          => 'No portfolio projects found',
        'not_found_in_trash' => 'No portfolio projects found in Trash',
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'portfolio-project' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'menu_icon'          => 'dashicons-portfolio',
        'supports'            => array('title', 'editor', 'thumbnail'),
    );

    register_post_type( 'portfolio_project', $args );
}
add_action( 'init', 'create_portfolio_post_type' );

/**
 * Create custom taxonomies for portfolio
 */
function create_portfolio_taxonomies() {
    // Add Project Category Taxonomy
    $labels = array(
        'name'              => 'Project Categories',
        'singular_name'     => 'Project Category',
        'search_items'      => 'Search Project Categories',
        'all_items'         => 'All Project Categories',
        'edit_item'         => 'Edit Project Category',
        'update_item'       => 'Update Project Category',
        'add_new_item'      => 'Add New Project Category',
        'new_item_name'     => 'New Project Category Name',
        'menu_name'         => 'Project Categories',
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'project-category' ),
    );

    register_taxonomy( 'portfolio_category', array( 'portfolio_project' ), $args );
}
add_action( 'init', 'create_portfolio_taxonomies', 0 );