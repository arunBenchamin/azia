<?php
/* 
Plugin Name: Azia Addon
Description: Addons for Azia WordPress Themes
Version: 1.0
Author: ColorBee
Text Domain: azia-addon
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
/**
 * Include all files
 */
include_once(plugin_dir_path(__FILE__) . 'include/class-ocdi-importer.php');

final class Azia_Elementor_Widgets
{
    const VERSION = '1.0.0';
    const MINIMUM_ELEMENTOR_VERSION = '3.0.0';
    const MINIMUM_PHP_VERSION = '7.3';

    private static $_instance = null;
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __construct()
    {
        add_action('init', [$this, 'i18n']);
        add_action('plugins_loaded', [$this, 'init']);
    }

    public function i18n()
    {
        load_plugin_textdomain('azia-addon');
    }

    public function init()
    {
        // Check if Elementor installed and activated
        if (!did_action('elementor/loaded')) {
            add_action('admin_notices', [$this, 'admin_notice_missing_elementor']);
            return;
        }

        // Check for required Elementor version
        if (!version_compare(ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=')) {
            add_action('admin_notices', [$this, 'admin_notice_minimum_elementor_version']);
            return;
        }

        // Check for required PHP version
        if (version_compare(PHP_VERSION, self::MINIMUM_PHP_VERSION, '<')) {
            add_action('admin_notices', [$this, 'admin_notice_minimum_php_version']);
            return;
        }

        // Add Plugin actions
        add_action('elementor/widgets/register', [$this, 'init_widgets']);
        add_action('elementor/elements/categories_registered', [$this, 'add_elementor_widget_categories']);
    }

    public function init_widgets($widgets_manager)
    {
        // Include Widget files
        require_once(__DIR__ . '/widgets/hero.php');
        require_once(__DIR__ . '/widgets/service.php');
        require_once(__DIR__ . '/widgets/contact.php');
        require_once(__DIR__ . '/widgets/text-section.php');
        require_once(__DIR__ . '/widgets/portfolio.php');
        require_once(__DIR__ . '/widgets/testimonial.php');


        // Register widget
        $widgets_manager->register(new \Elementor_Hero_Widget());
        $widgets_manager->register(new \Elementor_Service_Widget());
        $widgets_manager->register(new \Elementor_Contact_Widget());
        $widgets_manager->register(new \Elementor_Text_Section_Widget());
        $widgets_manager->register(new \Elementor_Portfolio_Widget());
        $widgets_manager->register(new \Elementor_Testimonial_Carousel_Widget());
    }

    public function add_elementor_widget_categories($elements_manager)
    {
        $elements_manager->add_category(
            'azia',
            [
                'title' => esc_html__('Azia', 'azia-addon'),
                'icon' => 'fas fa-building',
            ]
        );
    }

    public function admin_notice_missing_elementor()
    {
        if (isset($_GET['activate'])) unset($_GET['activate']);

        $message = sprintf(
            esc_html__('"%1$s" requires "%2$s" to be installed and activated.', 'azia-addon'),
            '<strong>' . esc_html__('Azia Widgets', 'azia-addon') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'azia-addon') . '</strong>'
        );

        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    public function admin_notice_minimum_elementor_version()
    {
        $message = sprintf(
            esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'azia-addon'),
            '<strong>' . esc_html__('Azia Widgets', 'azia-addon') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'azia-addon') . '</strong>',
            self::MINIMUM_ELEMENTOR_VERSION
        );

        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    public function admin_notice_minimum_php_version()
    {
        $message = sprintf(
            esc_html__('"%1$s" requires PHP version %2$s or greater.', 'azia-addon'),
            '<strong>' . esc_html__('Azia Widgets', 'azia-addon') . '</strong>',
            self::MINIMUM_PHP_VERSION
        );

        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }
}
//CPT
include(plugin_dir_path(__FILE__) . 'cpt/portfolio-post.php');

//Elementor settings
function add_elementor_header_controls()
{
    add_action('elementor/documents/register_controls', function ($document) {
        if (!$document instanceof \Elementor\Core\DocumentTypes\PageBase) {
            return;
        }
        // Register Custom Controls in Elementor Editor for Project Post Type
        if ('portfolio_project' !== get_post_type()) {
            return;
        }
        $document->start_controls_section(
            'header_settings',
            [
                'label' => __('Header Settings', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_SETTINGS,
            ]
        );

        $document->add_control(
            'page_description',
            [
                'label' => __('Small Description', 'azia-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => '',
            ]
        );

        $document->end_controls_section();

        $document->start_controls_section(
            'project_meta_section',
            [
                'label' => __('Portfolio Captions', 'azia-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_SETTINGS,
            ]
        );

        for ($i = 1; $i <= 2; $i++) {
            $document->add_control(
                "stat_icon_{$i}",
                [
                    'label' => __("Icon {$i}", 'azia-addon'),
                    'type' => \Elementor\Controls_Manager::ICONS,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'fa-solid',
                    ],

                ]
            );

            $document->add_control(

                "stat_label_{$i}",
                [
                    'label' => __("Label {$i}", 'azia-addon'),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => '',

                ]

            );
        }


        $document->end_controls_section();
    });
}
add_action('after_setup_theme', 'add_elementor_header_controls');

function adjust_color_brightness($hex, $shade = 500, $opacity = 1)
{
    // Normalize HEX (supports shorthand like #0af)
    $hex = ltrim($hex, '#');
    if (strlen($hex) === 3) {
        $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }

    // Convert hex to RGB
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));

    // Shade map inspired by Tailwind (lower is brighter)
    $brightness_map = [
        50 => 0.95,   // 95% white
        100 => 0.9,
        200 => 0.75,
        300 => 0.6,
        400 => 0.3,
        500 => 0,     // original color
        600 => -0.1,
        700 => -0.2,
        800 => -0.35,
        900 => -0.5,  // darkest
    ];

    // Clamp to known shades
    if (!isset($brightness_map[$shade])) {
        $shade = 500;
    }

    $mix = $brightness_map[$shade];

    // Mix with white or black
    if ($mix > 0) {
        // Lighten (mix with white)
        $r = $r + (255 - $r) * $mix;
        $g = $g + (255 - $g) * $mix;
        $b = $b + (255 - $b) * $mix;
    } elseif ($mix < 0) {
        // Darken (mix with black)
        $r = $r * (1 + $mix);
        $g = $g * (1 + $mix);
        $b = $b * (1 + $mix);
    }

    $r = round(min(max($r, 0), 255));
    $g = round(min(max($g, 0), 255));
    $b = round(min(max($b, 0), 255));

    return "rgba($r, $g, $b, $opacity)";
}

// Initialize the plugin
Azia_Elementor_Widgets::instance();




/**
 * Enqueue scripts and localize AJAX variables
 */
function azia_portfolio_enqueue_scripts()
{
    // Make sure jQuery is loaded
    wp_enqueue_script('jquery');

    // Localize the script with AJAX data
    // We'll attach this to jQuery since we're no longer using a separate file
    wp_localize_script(
        'jquery',
        'azia_ajax_object',
        array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('azia_ajax_nonce'),
        )
    );
}
add_action('wp_enqueue_scripts', 'azia_portfolio_enqueue_scripts');


/**
 * AJAX handler for loading portfolio pages
 */
function azia_load_portfolio_page()
{
    // Check nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'azia_ajax_nonce')) {
        wp_send_json_error(['message' => 'Invalid nonce']);
    }
    $current_page = isset($_POST['page']) ? intval($_POST['page']) : 1;
    $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
    $posts_per_page = isset($_POST['posts_per_page']) ? intval($_POST['posts_per_page']) : 5;
    $categories = isset($_POST['categories']) ? $_POST['categories'] : [];
    $orderby = isset($_POST['orderby']) ? sanitize_text_field($_POST['orderby']) : 'date';
    $order = isset($_POST['order']) ? sanitize_text_field($_POST['order']) : 'DESC';

    // Query Arguments
    $args = [
        'post_type' => 'portfolio_project',
        'posts_per_page' => $posts_per_page,
        'paged' => $page,
        'orderby' => $orderby,
        'order' => $order,
    ];

    // If it's a JSON string, decode it first
    if (is_string($categories) && (strpos($categories, '[') === 0 || strpos($categories, '{') === 0)) {
        $categories = json_decode(stripslashes($categories), true);
    }

    // Then check if it has meaningful content
    if (!empty($categories) && $categories !== '\"\"' && $categories !== '""') {
        $args['tax_query'] = [
            [
                'taxonomy' => 'portfolio_category',
                'field' => 'term_id',
                'terms' => $categories,
            ],
        ];
    }

    $query = new \WP_Query($args);
    $html = '';
    $pagination = '';

    if ($query->have_posts()) {
        ob_start();
        $counter = 0;

        while ($query->have_posts()) {
            $query->the_post();
            $counter++;

            // Get project details
            $project_categories = get_the_terms(get_the_ID(), 'portfolio_category');
            $cat_classes = [];
            $category_name = '';

            if (!empty($project_categories) && !is_wp_error($project_categories)) {
                foreach ($project_categories as $category) {
                    $cat_classes[] = 'cat-' . $category->term_id;
                    if (empty($category_name)) {
                        $category_name = $category->name;
                    }
                }
            }

            // Check if it's a full-width item (every 4th item)
            $full_width_class = ($counter % 4 === 0) ? 'lg:col-span-2' : '';

            // Include portfolio item HTML
            include(dirname(__FILE__) . '/widgets/templates/portfolio-item.php');
        }

        $html = ob_get_clean();
        wp_reset_postdata();

        // Generate pagination HTML
        ob_start();
        include_once(dirname(__FILE__) . '/widgets/templates/portfolio-pagination.php');
        $pagination = ob_get_clean();
    }

    wp_send_json_success([
        'html' => $html,
        'pagination' => $pagination
    ]);
}
add_action('wp_ajax_azia_load_portfolio_page', 'azia_load_portfolio_page');
add_action('wp_ajax_nopriv_azia_load_portfolio_page', 'azia_load_portfolio_page');


// AJAX handler for loading project details
function azia_load_portfolio_project()
{
    // Check nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'azia_ajax_nonce')) {
        wp_send_json_error(['message' => 'Invalid nonce']);
    }

    $project_id = isset($_POST['project_id']) ? intval($_POST['project_id']) : 0;

    if ($project_id <= 0) {
        wp_send_json_error(['message' => 'Invalid project ID']);
    }

    // Get project data
    $project = get_post($project_id);

    if (!$project) {
        wp_send_json_error(['message' => 'Project not found']);
    }

    // Get project details
    $category = '';
    $project_categories = get_the_terms($project_id, 'portfolio_category');
    if (!empty($project_categories) && !is_wp_error($project_categories)) {
        $category = $project_categories[0]->name;
    }

    // Get project services (could be stored as meta or taxonomy)
    $services = get_post_meta($project_id, '_project_services', true);

    // Get project meta data
    if (class_exists('\Elementor\Plugin') && class_exists('\Elementor\Core\Settings\Manager')) {
        try {
            $page_settings_manager = \Elementor\Core\Settings\Manager::get_settings_managers('page');
            if ($page_settings_manager) {
                $page_settings_model = $page_settings_manager->get_model($project_id);
                if ($page_settings_model) {
                    $stats_list = [];
                    $page_settings = $page_settings_model->get_settings();
                    for ($i = 1; $i <= 3; $i++) {
                        if (!empty($page_settings["stat_label_{$i}"])) {
                            $stats_list[] = [
                                'stat_icon'   => $page_settings["stat_icon_{$i}"] ?? null,
                                'stat_label'  => $page_settings["stat_label_{$i}"] ?? '',
                            ];
                        }
                    }
                }
            }
        } catch (Exception $e) {
            // Silently handle any errors that might occur when accessing Elementor
            error_log('Elementor settings access error: ' . $e->getMessage());
        }
    }


    ob_start();
?>
    <!-- Popup Header -->
    <div class="relative h-72 md:h-96 overflow-hidden">
        <?php if (has_post_thumbnail($project_id)) : ?>
            <?php echo get_the_post_thumbnail($project_id, 'large', ['class' => 'w-full h-full object-cover']); ?>
        <?php else : ?>
            <img src="<?php echo \Elementor\Utils::get_placeholder_image_src(); ?>" alt="<?php echo esc_attr($project->post_title); ?>" class="w-full h-full object-cover">
        <?php endif; ?>
        <div class="absolute inset-0 bg-gradient-to-t from-black/80 to-black/30"></div>

        <!-- Close button -->
        <button id="closePopupBtn" class="absolute top-4 right-4 bg-white/20 backdrop-blur-md p-2 rounded-full hover:bg-white/30 transition-colors text-white">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
        </button>

        <!-- Category badge -->
        <div class="absolute top-6 left-6">
            <?php if (!empty($category)) : ?>
                <div class="px-4 py-1.5 rounded-full text-sm font-medium bg-white/20 backdrop-blur-md text-white">
                    <?php echo esc_html($category); ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Title and client -->
        <div class="absolute bottom-0 left-0 right-0 p-6 md:p-8">
            <h2 class="text-2xl md:text-3xl font-bold text-white mb-2"><?php echo esc_html($project->post_title); ?></h2>
        </div>
    </div>

    <!-- Popup Content -->
    <div class="p-6 md:p-8">
        <!-- Stats -->
        <div class="flex flex-wrap gap-4 mb-6">

            <?php

            foreach ($stats_list as $stat):
            ?>
                <div class="flex flex-col items-center px-6 py-3 bg-gray-50 rounded-xl">
                    <span class="text-xl font-bold text-indigo-600">
                        <?php
                        if (!empty($stat['stat_icon']) && class_exists('\Elementor\Icons_Manager')) {
                        ?>
                            <i class="<?php echo esc_attr($stat['stat_icon']['value']); ?> mr-1.5"></i>
                        <?php
                        }
                        ?></span>
                    <span class="text-sm text-gray-500"><?php echo esc_html($stat['stat_label']); ?></span>
                </div>

            <?php

            endforeach; ?>


        </div>

        <!-- Project details -->
        <div class="mb-8">
            <div class="azia-text-desc text-section-content">
                <?php echo wpautop($project->post_content); ?>
            </div>
        </div>

        <!-- Services provided -->
        <?php if (!empty($services)) : ?>
            <div class="mb-8">
                <h3 class="text-xl font-semibold mb-4"><?php echo esc_html__('Services provided', 'azia-addon'); ?></h3>
                <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <?php foreach ($services as $service) : ?>
                        <div class="flex items-center">
                            <div class="w-2 h-2 bg-indigo-500 rounded-full mr-2"></div>
                            <span class="text-gray-700"><?php echo esc_html($service); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>


    </div>
<?php

    $html = ob_get_clean();
    wp_send_json_success(['html' => $html]);
}
add_action('wp_ajax_azia_load_portfolio_project', 'azia_load_portfolio_project');
add_action('wp_ajax_nopriv_azia_load_portfolio_project', 'azia_load_portfolio_project');

 
 add_action('elementor/init', function() {
    // Only run once
    if (get_option('azia_global_colors_set')) {
        return;
    }
    
    // Make sure we have the Plugin class
    if (!class_exists('\Elementor\Plugin')) {
        return;
    }
    
    // Get the global colors manager
    $kit_id = \Elementor\Plugin::$instance->kits_manager->get_active_id();
    if (!$kit_id) {
        return;
    }
    
    // Get the active kit document
    $kit = \Elementor\Plugin::$instance->documents->get($kit_id);
    if (!$kit) {
        return;
    }
    
    // Get current settings
    $meta_key = \Elementor\Core\Settings\Page\Manager::META_KEY;
    $kit_settings = get_post_meta($kit_id, $meta_key, true);
    
    if (!is_array($kit_settings)) {
        $kit_settings = [];
    }
    
    // Define your system colors
    $system_colors = [
        [
            '_id' => 'primary',
            'title' => 'Primary',
            'color' => '#0ea5e9',
        ],
        [
            '_id' => 'secondary',
            'title' => 'Secondary',
            'color' => '#6366f1',
        ],
        [
            '_id' => 'accent',
            'title' => 'Accent',
            'color' => '#f6339a',
        ],
     
    ];
    
    // Define your custom colors
   /* $custom_colors = [
        [
            '_id' => 'custom3',
            'title' => 'Custom 3',
            'color' => '#8B5CF6',
        ],
        [
            '_id' => 'custom4',
            'title' => 'Custom 4',
            'color' => '#EC4899',
        ],
    ];*/
    
    // Update kit settings with new colors
    $kit_settings['system_colors'] = $system_colors;
   // $kit_settings['custom_colors'] = $custom_colors;
    
    // Save the updated settings
    update_post_meta($kit_id, $meta_key, $kit_settings);
    
    // Mark as done
    update_option('azia_global_colors_set', true);
});